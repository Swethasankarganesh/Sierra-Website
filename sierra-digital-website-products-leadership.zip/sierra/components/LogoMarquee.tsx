export default function LogoMarquee({ items, logos, base }: { items: string[]; logos?: Record<string, string>; base?: string }) {
  const track = [...items, ...items]; // duplicated for a seamless loop, same pattern as the source site
  return <div className="group overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]">
    <ul className="marquee flex w-max items-center gap-24 py-4 group-hover:[animation-play-state:paused]">
      {track.map((c, i) => <li key={c + i} className="flex h-24 shrink-0 items-center whitespace-nowrap">
        {logos?.[c] ? /* eslint-disable-next-line @next/next/no-img-element */
          <img src={`${base}${logos[c]}`} alt={c} className="h-20 w-auto max-w-[260px] object-contain grayscale opacity-70 transition duration-300 group-hover:opacity-100 hover:grayscale-0 hover:opacity-100" loading="lazy" />
          : <span className="text-2xl font-semibold text-slate-400">{c}</span>}
      </li>)}
    </ul>
  </div>;
}
