"use client";
import { useEffect, useState } from "react";
import { Btn } from "./ui";
const SLIDES = [
  { eyebrow: "Unlock the Power of Your Business Data", title: "SAP Business Data Cloud (SAP BDC)", body: "Seamlessly connect, manage, and leverage your business information with SAP Business Data Cloud—delivered by Sierra Digital’s certified SAP experts for maximum impact.", cta: "Know More", href: "/solutions/business-data-cloud" },
  { eyebrow: "AI on SAP", title: "Doing AI Right with SAP", body: "End-to-End AI Strategy and Execution with best-in-class products and services to leverage SAP's AI Ecosystem to the Fullest.", cta: "Get Started", href: "/contact" },
  { eyebrow: "SAP Modernization Lifecycle", title: "Assess. Migrate. Transform. Run.", body: "Sierra Digital’s comprehensive products and services provide end-to-end support for SAP at your enterprise. With assessments, migration services, managed services, and pre-built content for both industry and line-of-business, Sierra Digital is prepared to tackle any challenge.", cta: "Get Started", href: "/contact" },
  { eyebrow: "Sierra AppHaus", title: "A Hub for Innovation", body: "Sierra Digital’s comprehensive products and services provide end-to-end support for SAP at your enterprise. With assessments, migration services, managed services, and pre-built content for both industry and line-of-business, Sierra Digital is prepared to tackle any challenge.", cta: "Know More", href: "/apphaus" },
];
export default function HeroSlides() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  useEffect(() => {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches || paused) return;
    const t = setInterval(() => setI(v => (v + 1) % SLIDES.length), 5500);
    return () => clearInterval(t);
  }, [paused]);
  const s = SLIDES[i];
  return <div onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
    <div className="relative min-h-[340px] md:min-h-[460px]">
      {SLIDES.map((sl, n) => <div key={sl.title} aria-hidden={n !== i} className={`transition-all duration-700 ease-out ${n === i ? "relative opacity-100 translate-y-0" : "pointer-events-none absolute inset-0 opacity-0 translate-y-3"}`}>
        <p className="mb-4 flex items-center gap-2 text-xs font-semibold tracking-[0.18em] text-cyan"><span className="live-dot" aria-hidden />{sl.eyebrow}</p>
        <h1 className="text-5xl font-semibold leading-[1.05] tracking-[-0.035em] sm:text-6xl md:text-7xl lg:text-8xl">{sl.title}</h1>
        <p className="mt-8 max-w-xl text-lg text-white/75 md:text-xl">{sl.body}</p>
      </div>)}
    </div>
    <div className="mt-9 flex flex-wrap items-center gap-6">
      <Btn href={s.href}>{s.cta}</Btn><Btn href="/contact" variant="light">Talk to Our Experts</Btn>
      <div className="flex gap-2" role="tablist" aria-label="Hero slides">{SLIDES.map((sl, n) => <button key={sl.title} role="tab" aria-selected={n === i} aria-label={`Slide ${n + 1}: ${sl.title}`} onClick={() => setI(n)} className={`h-1.5 rounded-full transition-all ${n === i ? "w-7 bg-cyan" : "w-1.5 bg-white/30 hover:bg-white/50"}`} />)}</div>
    </div>
  </div>;
}
