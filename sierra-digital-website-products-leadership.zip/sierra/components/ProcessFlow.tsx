export default function ProcessFlow({ steps, vertical = false, label }: { steps: string[]; vertical?: boolean; label: string }) {
  const step = 9 / steps.length;
  return <ol aria-label={label} className={vertical ? "grid gap-6" : "grid gap-6 md:grid-flow-col md:auto-cols-fr md:gap-5"}>{steps.map((s, i) => <li key={s} className="relative">
    <div className="flow-node rounded-2xl border border-line bg-white px-4 py-3 text-sm font-medium" style={{ "--i": i, "--step": `${step}s` } as React.CSSProperties}>{s}</div>
    {i < steps.length - 1 && <span aria-hidden className={vertical ? "absolute left-6 top-full text-accent" : "absolute left-6 top-full text-accent md:left-auto md:right-[-15px] md:top-2.5"}>{vertical ? "↓" : <><span className="md:hidden">↓</span><span className="hidden md:inline">→</span></>}</span>}
  </li>)}</ol>;
}
