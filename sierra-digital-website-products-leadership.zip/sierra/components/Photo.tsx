import LiveDiagram from "./LiveDiagram";

// Real photography hotlinked live from Unsplash's CDN at request time (Unsplash License — free for commercial
// use). Each id below was checked individually for a "free to use" licence, not "Unsplash+". Photographer credit
// kept here per Unsplash's community guidelines even though the licence doesn't require on-page attribution.
export const REAL_PHOTOS: Record<string, { file: string; credit: string; page: string }> = {
  "hero-mountain-digital": { file: "photo-1638989629000-c55c67d6ab47", credit: "Gleb Lucky", page: "https://unsplash.com/photos/UI0eIMjPk4w" },
  energy: { file: "photo-1582258119432-c04c9f5aa95c", credit: "Chalo Garcia", page: "https://unsplash.com/photos/SlCzvSgygqQ" },
  "smart-manufacturing": { file: "photo-1716191299980-a6e8827ba10b", credit: "Homa Appliances", page: "https://unsplash.com/photos/sz1CHL7Pky0" },
  aerospace: { file: "photo-1686953626953-3556f6c8136d", credit: "Niels Baars", page: "https://unsplash.com/photos/KFaqjSVIKhA" },
};
const cdn = (file: string, w: number) => `https://images.unsplash.com/${file}?w=${w}&q=75&auto=format&fit=crop&ixlib=rb-4.1.0`;

const DIAGRAMS: Record<string, "network" | "dashboard" | "architecture"> = {
  "data-analytics": "dashboard",
  "data-cloud": "network",
  "cloud-integration": "network",
  "enterprise-architecture": "architecture",
};

export default function Photo({ name, sizes = "100vw", priority = false, className = "", alt = "" }: { name: string; sizes?: string; priority?: boolean; className?: string; alt?: string }) {
  if (DIAGRAMS[name]) {
    return <LiveDiagram kind={DIAGRAMS[name]} className={className} />;
  }
  const real = REAL_PHOTOS[name];
  const s1600 = real ? cdn(real.file, 1600) : `/images/${name}-1600.webp`;
  const s800 = real ? cdn(real.file, 800) : `/images/${name}-800.webp`;
  return <img src={s1600} srcSet={`${s800} 800w, ${s1600} 1600w`} sizes={sizes} width={1600} height={900} alt={alt} aria-hidden={alt ? undefined : true} loading={priority ? "eager" : "lazy"} decoding="async" {...(priority ? { fetchPriority: "high" as const } : {})} className={className} referrerPolicy="no-referrer" />;
}
