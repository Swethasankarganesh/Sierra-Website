"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { ChevronDown, Menu, X, ArrowRight } from "lucide-react";
import Logo from "./Logo";
import { menus } from "@/lib/data";

export default function Header() {
  const [open, setOpen] = useState<string | null>(null);
  const [mob, setMob] = useState(false);
  const [sc, setSc] = useState(false);
  const path = usePathname();
  useEffect(() => { setOpen(null); setMob(false); }, [path]);
  useEffect(() => { const f = () => setSc(scrollY > 12); f(); addEventListener("scroll", f, { passive: true }); return () => removeEventListener("scroll", f); }, []);

  return <header onKeyDown={e => e.key === "Escape" && setOpen(null)} className="sticky top-0 z-40">
    {/* Floating pill navbar: detached from the viewport edge, with its own rounded, blurred shell. */}
    <div className={`mx-auto max-w-7xl px-4 transition-[padding] duration-300 md:px-6 ${sc ? "pb-3 pt-3" : "pb-5 pt-5"}`}>
      <div onMouseLeave={() => setOpen(null)} className={`relative mx-auto flex h-16 max-w-6xl items-center justify-between rounded-full border border-line/80 bg-white/85 pl-5 pr-2 shadow-[0_1px_2px_rgba(16,24,40,.04)] backdrop-blur-md transition-shadow duration-300 ${sc ? "shadow-[0_12px_32px_-12px_rgba(16,24,40,.18)]" : ""}`}>
        <Logo />
        <nav aria-label="Main" className="hidden items-center gap-1 xl:flex">
          {menus.map(m => <div key={m.label} className="relative" onMouseEnter={() => setOpen(m.label)}>
            <button aria-expanded={open === m.label} onClick={() => setOpen(open === m.label ? null : m.label)}
              className={`flex items-center gap-1 rounded-full px-4 py-2 text-[14px] font-medium transition-colors ${open === m.label ? "bg-mist text-accent" : "text-ink/80 hover:bg-mist hover:text-accent"}`}>
              {m.label}<ChevronDown size={13} className={`transition-transform ${open === m.label ? "rotate-180" : ""}`} />
            </button>
            {open === m.label && <div className={`absolute left-1/2 top-[calc(100%+14px)] -translate-x-1/2 rounded-2xl border border-line bg-white p-6 shadow-xl ${m.groups.length > 1 ? "w-[720px]" : "w-[400px]"}`}>
              <div className={`grid gap-8 ${m.groups.length > 1 ? "grid-cols-2" : ""}`}>
                {m.groups.map(g => <div key={g.title}><p className="mb-3 text-xs font-semibold text-slate-500">{g.title}</p><ul className="space-y-1">{g.items.map(i => <li key={i.href}><Link href={i.href} className="group block rounded-xl p-2 hover:bg-mist"><span className="flex items-center gap-1 font-medium">{i.t}<ArrowRight size={14} className="opacity-0 transition group-hover:translate-x-1 group-hover:opacity-100" /></span><span className="block text-sm text-slate-600">{i.d}</span></Link></li>)}</ul></div>)}
              </div>
              <Link href={m.href} className="mt-4 inline-block text-sm font-medium text-accent">View all {m.label}</Link>
            </div>}
          </div>)}
        </nav>
        <div className="flex items-center gap-2">
          <Link href="/contact" className="hidden rounded-full bg-accent px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-brand sm:block">Get Started</Link>
          <button className="grid h-10 w-10 place-items-center rounded-full hover:bg-mist xl:hidden" aria-label={mob ? "Close menu" : "Open menu"} aria-expanded={mob} onClick={() => setMob(!mob)}>{mob ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
      </div>

      {mob && <nav aria-label="Mobile" className="mx-auto mt-3 max-h-[75vh] max-w-6xl overflow-y-auto rounded-3xl border border-line bg-white p-4 shadow-xl xl:hidden">
        {menus.map(m => <details key={m.label} className="border-b border-line py-3 last:border-0"><summary className="cursor-pointer list-none px-2 font-medium">{m.label}</summary><ul className="mt-2 space-y-2 px-2 pl-4">
          <li><Link href={m.href} className="text-accent">All {m.label}</Link></li>{m.groups.flatMap(g => g.items).map(i => <li key={i.href}><Link href={i.href}>{i.t}</Link></li>)}
        </ul></details>)}
        <Link href="/contact" className="mt-4 block rounded-full bg-accent py-3 text-center font-medium text-white">Get Started</Link>
      </nav>}
    </div>
  </header>;
}
