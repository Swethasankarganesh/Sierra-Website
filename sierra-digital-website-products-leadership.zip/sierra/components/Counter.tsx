"use client";
import { useEffect, useRef, useState } from "react";
export default function Counter({ v, s }: { v: number; s: string }) {
  const ref = useRef<HTMLSpanElement>(null), [n, setN] = useState(0);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) { setN(v); return; }
    const io = new IntersectionObserver(([e]) => { if (!e.isIntersecting) return; io.disconnect(); const t0 = performance.now(); const f = (t: number) => { const p = Math.min((t - t0) / 900, 1); setN(Math.round(v * (1 - (1 - p) ** 3))); if (p < 1) requestAnimationFrame(f); }; requestAnimationFrame(f); });
    io.observe(el); return () => io.disconnect();
  }, [v]);
  return <span ref={ref} aria-label={`${v}${s}`}>{n}{s}</span>;
}
