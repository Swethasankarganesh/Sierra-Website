import Link from "next/link";
import { LOGO } from "@/lib/data";
export default function Logo({ className = "" }: { className?: string }) {
  return <Link href="/" aria-label="Sierra Digital home" className={`inline-flex items-center ${className}`}>{/* eslint-disable-next-line @next/next/no-img-element */}<img src={LOGO.src} width={LOGO.w} height={LOGO.h} alt="Sierra Digital" className="h-7 w-auto" /></Link>;
}
