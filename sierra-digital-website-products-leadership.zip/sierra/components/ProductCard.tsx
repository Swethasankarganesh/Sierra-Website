import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Icon } from "./ui";
import { productBrand } from "@/data/productBrand";
import type { Product } from "@/data/products";
/** One product tile: fixed-ratio local photo (no layout shift), brand icon, equal-height body, aligned "Explore Product" button. */
export default function ProductCard({ p }: { p: Product }) {
  const href = `/products/${p.slug}`;
  return <article className="group flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl">
    <Link href={href} tabIndex={-1} aria-hidden className="relative block aspect-[16/10] overflow-hidden bg-navy">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={`/images/${p.img}-800.webp`} srcSet={`/images/${p.img}-800.webp 800w, /images/${p.img}-1600.webp 1600w`} sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw" width={800} height={500} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
      <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-navy/80 via-navy/10 to-transparent" />
      <span className="absolute left-5 top-5 rounded-full bg-white/95 px-3 py-1 text-xs font-semibold text-navy">{p.tag}</span>
    </Link>
    <div className="flex flex-1 flex-col p-7 md:p-8">
      <div className="flex items-center gap-4"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl text-white shadow-sm" style={{ background: productBrand[p.slug] }}><Icon name={p.icon} size={22} /></span><h3 className="text-2xl font-semibold tracking-tight"><Link href={href} className="hover:text-accent">{p.title}</Link></h3></div>
      <p className="mt-5 flex-1 text-[15px] leading-relaxed text-slate-600">{p.desc}</p>
      <Link href={href} aria-label={`Explore ${p.title}`} className="mt-8 inline-flex w-full items-center justify-center gap-2 rounded-md bg-accent px-5 py-3 text-[15px] font-medium text-white transition hover:bg-brand">Explore Product<ArrowRight size={16} className="transition-transform group-hover:translate-x-1" /></Link>
    </div>
  </article>;
}
