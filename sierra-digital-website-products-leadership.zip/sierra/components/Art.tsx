export function MountainHero({ className = "" }: { className?: string }) {
  const N = ({ x, y }: { x: number; y: number }) => <g><circle cx={x} cy={y} r="24" fill="url(#glow)" /><circle cx={x} cy={y} r="5" fill="#cfe2ff" /></g>;
  const T = ({ x, y, t, s, end = false }: { x: number; y: number; t: string; s: string; end?: boolean }) => <g textAnchor={end ? "end" : "start"}><text x={x} y={y} fill="#fff" fontSize="16" fontWeight="600">{t}</text><text x={x} y={y + 17} fill="#b9c9e8" fontSize="12">{s}</text></g>;
  return <svg className={className} viewBox="0 0 900 560" preserveAspectRatio="xMaxYMax slice" aria-hidden="true">
    <defs><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#0a1a40" /><stop offset="1" stopColor="#12306a" /></linearGradient>
      <linearGradient id="mt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#4a6aa3" /><stop offset="1" stopColor="#0c1c42" /></linearGradient>
      <radialGradient id="glow"><stop offset="0" stopColor="#7fb2ff" stopOpacity=".9" /><stop offset="1" stopColor="#7fb2ff" stopOpacity="0" /></radialGradient></defs>
    <rect width="900" height="560" fill="url(#sky)" />
    <path d="M0 560V380L90 330 160 370 270 250 330 300 420 150 490 210 530 120 590 230 650 190 740 290 800 260 900 330V560Z" fill="url(#mt)" />
    <path d="M530 120 498 205 520 190 540 215 565 180 590 230 560 165Z" fill="#eaf1ff" opacity=".55" /><path d="M420 150 395 215 415 200 440 225 455 190 490 210 445 175Z" fill="#eaf1ff" opacity=".35" />
    <path d="M0 560V460L120 415 260 470 410 420 560 480 700 430 900 470V560Z" fill="#060e24" />
    <g fill="none" stroke="#7fb2ff" strokeWidth="1.5" opacity=".8"><path className="dash" d="M530 120Q600 130 650 190" /><path className="dash" d="M530 120Q450 150 420 235" /><path className="dash" d="M420 235Q520 330 620 380" /><path className="dash" d="M650 190Q690 300 620 380" /></g>
    <N x={530} y={120} /><N x={650} y={190} /><N x={420} y={235} /><N x={620} y={380} />
    <T x={548} y={92} t="SAP" s="Modernize and grow" /><T x={668} y={186} t="AI" s="Automate and innovate" /><T x={402} y={232} t="DATA" s="Turn insight into impact" end /><T x={640} y={382} t="PEOPLE" s="Enable what's next" />
  </svg>;
}
export function MountainBand({ className = "" }: { className?: string }) {
  return <svg className={className} viewBox="0 0 900 300" preserveAspectRatio="xMaxYMax slice" aria-hidden="true"><path d="M0 300V210L120 170 230 220 350 120 450 60 540 150 640 90 760 190 900 140V300Z" fill="#b4c8e6" /><path d="M450 60 415 135 440 120 462 145 490 110 540 150 480 105Z" fill="#f4f8ff" opacity=".9" /><path d="M0 300V250L160 215 320 260 480 225 640 265 780 235 900 260V300Z" fill="#8eaad0" /></svg>;
}
