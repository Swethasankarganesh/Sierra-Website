import { Container, Heading } from "./ui";
const src = [["ECC Production · ABAP", 100], ["S/4HANA Sandbox", 100], ["SAP BTP · Integration Suite", 82]] as const;
const steps = [["Ask", "Natural-language answers across your entire SAP estate. Readiness scores, custom-object inventory, integration dependencies, grounded in real system data."], ["Assess", "Live migration readiness. Grade ECC tables, flag clean-core blockers and project your RISE timeline."], ["Act", "Guided clean-core remediation. From flagged Z-objects to a sequenced plan with owners and effort estimates."]];
export default function Cockpit() {
  return <section id="cockpit" className="scroll-mt-20 bg-mist py-24 md:py-28"><Container><Heading h="One co-pilot for the whole transformation." sub="Sierra's AI RISE Cockpit guides SAP teams from first question to clean-core go-live." />
    <div className="mt-14 grid items-start gap-12 lg:grid-cols-2">
      <div className="space-y-5">{steps.map(([t, d]) => <div key={t} className="rounded-2xl border-l-4 border-accent bg-white p-7"><h3 className="font-semibold">{t}</h3><p className="mt-2 text-slate-600">{d}</p></div>)}</div>
      <div className="rounded-2xl border border-line bg-white p-8 shadow-sm md:p-10" role="img" aria-label="AI RISE Cockpit dashboard: connected sources, 74% RISE readiness, 38 clean-core actions, sequenced plan">
        <p className="text-sm font-semibold tracking-wide text-slate-500">CONNECTED SAP SOURCES</p>
        <div className="mt-5 space-y-5">{src.map(([n, p]) => <div key={n}><div className="flex justify-between text-sm"><span>{n}</span><span className="font-medium">{p}%</span></div><div className="mt-2 h-2 rounded-full bg-mist"><div className="h-2 rounded-full bg-accent" style={{ width: `${p}%` }} /></div></div>)}</div>
        <div className="mt-8 grid grid-cols-2 gap-5"><div className="rounded-xl bg-mist p-6"><p className="text-4xl font-semibold text-accent">74%</p><p className="mt-1 text-sm text-slate-600">RISE readiness</p></div><div className="rounded-xl bg-mist p-6"><p className="text-4xl font-semibold text-accent">38</p><p className="mt-1 text-sm text-slate-600">Clean-core actions</p></div></div>
        <div className="mt-8 border-t border-line pt-6 text-sm"><p className="font-semibold text-slate-500">SEQUENCED PLAN</p><p className="mt-2 leading-relaxed">Phase 1 · Remediate 12 custom Z-reports → SAC. Owner: BI team · Est. 3 weeks.</p></div>
      </div></div></Container></section>;
}
