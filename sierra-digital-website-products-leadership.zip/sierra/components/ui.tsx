import Link from "next/link";
import { ArrowRight, ChevronRight } from "lucide-react";
import * as Icons from "lucide-react";
import Photo from "./Photo";
import Reveal from "./Reveal";
export const Container = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => <div className={`mx-auto w-full max-w-7xl px-6 md:px-10 ${className}`}>{children}</div>;
export function Btn({ href, children, variant = "primary" }: { href: string; children: React.ReactNode; variant?: "primary" | "secondary" | "light" }) {
  const c = { primary: "btn-shine bg-accent text-white hover:bg-brand", secondary: "border border-navy text-navy hover:bg-navy hover:text-white", light: "border border-white/70 text-white hover:bg-white hover:text-navy" }[variant];
  return <Link href={href} className={`group relative inline-flex items-center gap-2 overflow-hidden rounded-md px-6 py-3 text-[15px] font-medium active:scale-[.97] ${c}`}>{children}<ArrowRight size={16} className="transition-transform group-hover:translate-x-1" /></Link>;
}
export const Heading = ({ h, sub, eyebrow, dark }: { h: string; sub?: string; eyebrow?: string; dark?: boolean }) => <Reveal className="max-w-3xl">{eyebrow && <p className={`mb-3 text-xs font-semibold tracking-[0.18em] ${dark ? "text-cyan" : "text-accent"}`}>{eyebrow.toUpperCase()}</p>}<h2 className={`text-3xl font-semibold tracking-[-0.02em] md:text-5xl ${dark ? "text-white" : ""}`}>{h}</h2>{sub && <p className={`mt-3 text-lg ${dark ? "text-white/70" : "text-slate-600"}`}>{sub}</p>}</Reveal>;
export const More = ({ href, children, dark }: { href: string; children: React.ReactNode; dark?: boolean }) => <Link href={href} className={`inline-flex items-center gap-1 whitespace-nowrap text-sm font-medium ${dark ? "text-cyan" : "text-accent"} hover:underline`}>{children}<ArrowRight size={14} /></Link>;
export const Icon = ({ name, size = 24 }: { name: string; size?: number }) => { const I = (Icons as unknown as Record<string, React.ComponentType<{ size?: number }>>)[name] ?? Icons.Circle; return <I size={size} />; };
export function Crumbs({ items, dark }: { items: { t: string; href?: string }[]; dark?: boolean }) {
  return <nav aria-label="Breadcrumb" className={`text-sm ${dark ? "text-white/60" : "text-slate-500"}`}><ol className="flex flex-wrap items-center gap-1"><li><Link href="/" className="hover:text-white">Home</Link></li>{items.map((i, n) => <li key={n} className="flex items-center gap-1"><ChevronRight size={14} />{i.href ? <Link href={i.href} className="hover:text-white">{i.t}</Link> : <span aria-current="page" className="text-white/90">{i.t}</span>}</li>)}</ol></nav>;
}
export const PageHead = ({ crumbs, title, intro, img }: { crumbs: { t: string; href?: string }[]; title: string; intro: string; img?: string }) => <div className="relative overflow-hidden bg-gradient-to-br from-navy to-navy2 py-16 text-white md:py-20">{img && <><Photo name={img} priority className="absolute inset-0 h-full w-full object-cover" /><div className="absolute inset-0 bg-gradient-to-r from-navy via-navy/85 to-navy/35" aria-hidden /></>}<Container className="relative"><Crumbs items={crumbs} dark /><h1 className="mt-5 max-w-4xl text-4xl font-semibold tracking-tight md:text-6xl">{title}</h1><p className="mt-4 max-w-2xl text-lg text-white/80">{intro}</p></Container></div>;
const MEET_URL = "https://outlook.office365.com/book/BookacallwithourBTPExperts@sierradigitalinc.com/?ismsaljsauthenabled=true";
const ctaFacts = [["800+", "Consultants across North America, Europe, Australia and Asia"], ["25+", "SAP BTP solutions to accelerate innovation"], ["2002", "Founded, with delivery centers in the U.S. and India"]];
// Static (no scroll animation) so nothing pops in; the navy base colour is already on screen before the photo paints.
export const CTA = ({ h = "Connect Businesses with Cutting-Edge Technologies for Innovation", p = "Don’t wait – future-proof your business now!" }: { h?: string; p?: string }) => <section className="relative isolate overflow-hidden bg-navy text-white">
  {/* eslint-disable-next-line @next/next/no-img-element */}
  <img src="/images/consulting-1600.webp" srcSet="/images/consulting-800.webp 800w, /images/consulting-1600.webp 1600w" sizes="100vw" width={1600} height={900} alt="" aria-hidden decoding="async" loading="lazy" className="absolute inset-0 -z-20 h-full w-full object-cover" />
  <div aria-hidden className="absolute inset-0 -z-10 bg-gradient-to-r from-navy via-navy/90 to-navy/45" />
  <Container className="grid items-center gap-16 py-24 md:py-32 lg:grid-cols-[1.15fr_0.85fr] lg:gap-24">
    <div>
      <h2 className="max-w-2xl text-4xl font-semibold leading-[1.15] tracking-tight md:text-5xl lg:text-6xl">{h}</h2>
      <p className="mt-7 max-w-xl text-lg leading-relaxed text-white/85 md:text-xl">{p}</p>
      <div className="mt-11 flex flex-wrap gap-4"><Btn href="/contact">Ask Our Experts</Btn><Btn href={MEET_URL} variant="light">Book a Meeting</Btn></div>
    </div>
    <ul className="grid gap-5 sm:grid-cols-3 lg:grid-cols-1">{ctaFacts.map(([n, t]) => <li key={n} className="rounded-xl border border-white/15 bg-navy/60 p-6 backdrop-blur-sm lg:flex lg:items-center lg:gap-6 lg:p-7"><p className="text-4xl font-semibold text-cyan lg:w-28 lg:shrink-0 lg:text-5xl">{n}</p><p className="mt-2 text-sm leading-relaxed text-white/80 lg:mt-0 lg:text-base">{t}</p></li>)}</ul>
  </Container></section>;
