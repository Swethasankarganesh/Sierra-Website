import Link from "next/link";
import { Linkedin, Facebook, Instagram, Youtube } from "lucide-react";
import { LOGO, solutions, services, industries, company, products, social, partners } from "@/lib/data";
const SOCIAL_ICON: Record<string, React.ComponentType<{ size?: number }>> = { LinkedIn: Linkedin, Facebook, Instagram, YouTube: Youtube };
const XGlyph = ({ size = 18 }: { size?: number }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden><path d="M18.9 2H22l-7.6 8.7L23.3 22h-7.1l-5.6-6.8L4 22H1l8.1-9.3L.9 2H8l5 6.2L18.9 2Zm-1.2 18h1.9L6.4 4h-2l13.3 16Z" /></svg>;
const cols: { t: string; l: string[][] }[] = [
  { t: "Solutions", l: solutions.slice(0, 6).map(s => [s.title, `/solutions/${s.slug}`]) },
  { t: "Services", l: [...services.map(s => [s.title, `/services/${s.slug}`]), ["Business processes", "/business-transformation/processes"]] },
  { t: "Products", l: [...products.map(p => [p.title, `/products/${p.slug}`])] },
  { t: "Industries", l: [...industries.slice(0, 5).map(i => [i.title, `/industries/${i.slug}`]), ["All industries", "/industries"]] },
  { t: "Company", l: [...Object.entries(company).map(([k, v]) => [v.title, `/company/${k}`]), ["Resources", "/insights"], ["AppHaus", "/apphaus"], ["Contact", "/contact"]] },
];
const MEET = "https://outlook.office365.com/book/BookacallwithourBTPExperts@sierradigitalinc.com/?ismsaljsauthenabled=true";
const h3 = "text-xs font-semibold tracking-[0.18em] text-white";
export default function Footer() {
  return <footer className="bg-navy text-white/75">
    {/* Top band: brand, follow-us, partners */}
    <div className="mx-auto grid max-w-7xl gap-14 px-6 py-20 md:px-10 lg:grid-cols-[1.2fr_1fr] lg:gap-24">
      <div>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <Link href="/" aria-label="Sierra Digital home" className="inline-block"><img src={LOGO.white} alt="Sierra Digital" width={LOGO.w} height={LOGO.h} className="h-8 w-auto" /></Link>
        <p className="mt-6 max-w-md text-base leading-relaxed">SAP Gold Partner. BTP &amp; AI Innovation Station. Helping enterprises modernize, innovate, and drive smarter business outcomes.</p>
        <div className="mt-10 flex flex-wrap gap-x-10 gap-y-6 text-sm">
          <div><h2 className={h3}>DOWNLOADS</h2><Link href="/products" className="mt-3 inline-block hover:text-white">Our Brochures</Link></div>
          <div><h2 className={h3}>MEETING WITH EXPERTS</h2><a href={MEET} target="_blank" rel="noopener noreferrer" className="mt-3 inline-block hover:text-white">Book a Meeting</a></div>
        </div>
      </div>
      <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-1 lg:gap-14">
        <div><h2 className={h3}>FOLLOW US ON</h2>
          <ul className="mt-5 flex flex-wrap gap-4">{social.map(([t, h]) => { const I = SOCIAL_ICON[t]; return <li key={t as string}><a href={h} target="_blank" rel="noopener noreferrer" aria-label={`Sierra Digital on ${t}`} title={t as string} className="grid h-12 w-12 place-items-center rounded-full border border-white/20 text-white/80 transition hover:-translate-y-0.5 hover:border-cyan hover:bg-white/5 hover:text-cyan">{I ? <I size={20} /> : <XGlyph />}</a></li>; })}</ul></div>
        <div><h2 className={h3}>OUR PARTNERS</h2>
          <ul className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-4">{partners.map(p => <li key={p} className="grid h-14 place-items-center rounded-lg border border-white/15 bg-white/[0.03] text-sm font-medium text-white/85"><Link href="/company/partners" className="grid h-full w-full place-items-center hover:text-cyan">{p}</Link></li>)}</ul></div>
      </div>
    </div>
    {/* Link columns */}
    <div className="border-t border-white/10"><div className="mx-auto grid max-w-7xl gap-x-10 gap-y-12 px-6 py-16 sm:grid-cols-2 md:px-10 lg:grid-cols-5">
      {cols.map(c => <div key={c.t}><h2 className="mb-5 text-sm font-semibold text-white">{c.t}</h2><ul className="space-y-3 text-sm">{c.l.map(([t, h]) => <li key={h + t}><Link href={h} className="inline-block leading-snug hover:text-white">{t}</Link></li>)}</ul></div>)}
    </div></div>
    <div className="border-t border-white/10"><div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-7 text-sm md:px-10"><span>© 2026 Sierra Digital. All rights reserved.</span><span className="flex gap-6"><Link href="/legal/privacy" className="hover:text-white">Privacy</Link><Link href="/legal/terms" className="hover:text-white">Terms</Link><Link href="/legal/cookies" className="hover:text-white">Cookies</Link></span></div></div>
  </footer>;
}
