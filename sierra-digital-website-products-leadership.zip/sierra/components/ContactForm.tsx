"use client";
import { useState } from "react";
import { solutions, processes } from "@/lib/data";
type St = "idle" | "sending" | "ok" | "err";
export default function ContactForm() {
  const [st, setSt] = useState<St>("idle"), [errs, setErrs] = useState<Record<string, string>>({}), [msg, setMsg] = useState("");
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = e.currentTarget, d = Object.fromEntries(new FormData(f)) as Record<string, string>, er: Record<string, string> = {};
    if (!d.name?.trim()) er.name = "Enter your name."; if (!/^\S+@\S+\.\S+$/.test(d.email ?? "")) er.email = "Enter a valid work email."; if (!d.company?.trim()) er.company = "Enter your company.";
    setErrs(er); if (Object.keys(er).length) return; setSt("sending");
    try { const r = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(d) }); const j = await r.json(); if (!r.ok) throw new Error(j.error); setSt("ok"); f.reset(); } catch (x) { setMsg((x as Error).message || "Something went wrong."); setSt("err"); }
  }
  const I = "mt-1 w-full rounded-2xl border border-line bg-white px-3 py-2.5 focus:border-accent";
  const F = ({ n, l, t = "text", req = false }: { n: string; l: string; t?: string; req?: boolean }) => <label className="block text-sm font-medium">{l}{req && " *"}<input name={n} type={t} className={I} aria-invalid={!!errs[n]} aria-describedby={errs[n] ? `${n}-e` : undefined} />{errs[n] && <span id={`${n}-e`} className="text-red-700">{errs[n]}</span>}</label>;
  if (st === "ok") return <div role="status" className="border-l-4 border-accent bg-mist p-7 md:p-8"><h2 className="text-xl font-semibold">Request received</h2><p className="mt-2 text-slate-600">Thank you. We'll be in touch.</p></div>;
  return <form onSubmit={submit} noValidate className="grid gap-4 sm:grid-cols-2">
    <F n="name" l="Name" req /><F n="email" l="Business email" t="email" req /><F n="company" l="Company" req /><F n="role" l="Job role" /><F n="country" l="Country" />
    <label className="block text-sm font-medium">Area of interest<select name="interest" className={I}><option value="">Select</option>{processes.map(p => <option key={p.slug}>{p.title}</option>)}{solutions.map(s => <option key={s.slug}>{s.title}</option>)}</select></label>
    <label className="block text-sm font-medium sm:col-span-2">Message<textarea name="message" rows={4} className={I} /></label>
    <input name="website" tabIndex={-1} autoComplete="off" aria-hidden className="hidden" />
    <div className="sm:col-span-2"><button disabled={st === "sending"} className="rounded-full bg-accent px-6 py-3 font-medium text-white hover:bg-brand disabled:opacity-60">{st === "sending" ? "Sending…" : "Start the Conversation"}</button>{st === "err" && <p role="alert" className="mt-3 text-red-700">{msg}</p>}</div></form>;
}
