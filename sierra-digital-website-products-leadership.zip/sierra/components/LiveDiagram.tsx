"use client";
// Minimal, always-moving SVG diagrams — used in place of stock "abstract tech" imagery.
// Motion communicates the underlying concept (data flow, sync, architecture) rather than decorating it.
const wrap = "flex h-full w-full items-center justify-center bg-gradient-to-br from-navy to-navy2";

function Nodes() {
  const pts = [[70, 60], [230, 40], [230, 120], [70, 140], [150, 90]];
  const edges = [[0, 4], [1, 4], [2, 4], [3, 4]];
  return <svg viewBox="0 0 300 180" className="h-full w-full" aria-hidden>
    <g stroke="#5aa9ff" strokeWidth="1.5" fill="none" opacity=".75">{edges.map(([a, b], i) => <path key={i} className="dash" d={`M${pts[a][0]} ${pts[a][1]} L${pts[b][0]} ${pts[b][1]}`} />)}</g>
    {pts.map(([x, y], i) => <circle key={i} cx={x} cy={y} r={i === 4 ? 10 : 6} fill="#5aa9ff"><animate attributeName="opacity" values="0.5;1;0.5" dur="2.4s" begin={`${i * 0.3}s`} repeatCount="indefinite" /></circle>)}
  </svg>;
}
function Dashboard() {
  const bars = [40, 70, 50, 90, 65, 100];
  return <svg viewBox="0 0 300 180" className="h-full w-full" aria-hidden>
    <line x1="30" y1="150" x2="280" y2="150" stroke="#2a4a78" />
    {bars.map((h, i) => <rect key={i} x={45 + i * 40} width="22" y={150 - h} height={h} rx="3" fill="#5aa9ff" opacity=".85"><animate attributeName="height" values={`0;${h};${h}`} dur="1.6s" begin={`${i * 0.12}s`} fill="freeze" /><animate attributeName="y" values={`150;${150 - h};${150 - h}`} dur="1.6s" begin={`${i * 0.12}s`} fill="freeze" /></rect>)}
    <path d="M45 110 85 95 125 120 165 70 205 90 245 55" stroke="#e6a23c" strokeWidth="2" fill="none" className="dash" />
  </svg>;
}
function Architecture() {
  const rows = [["Business processes", 30], ["SAP · Applications", 66], ["Integration layer", 102], ["Data & AI", 138]];
  return <svg viewBox="0 0 300 180" className="h-full w-full" aria-hidden>
    {rows.map(([label, y], i) => <g key={label as string}>
      <rect x="30" y={y as number} width="240" height="24" rx="4" fill="#12306a" stroke="#3a6bb0" />
      <text x="42" y={(y as number) + 16} fill="#cfe2ff" fontSize="10">{label}</text>
    </g>)}
    <g stroke="#5aa9ff" strokeWidth="1.5"><path className="dash" d="M150 54 V66" /><path className="dash" d="M150 90 V102" /><path className="dash" d="M150 126 V138" /></g>
  </svg>;
}
const KINDS = { network: Nodes, dashboard: Dashboard, architecture: Architecture };
export default function LiveDiagram({ kind, className = "" }: { kind: keyof typeof KINDS; className?: string }) {
  const K = KINDS[kind];
  return <div className={`${wrap} ${className}`}><K /></div>;
}
