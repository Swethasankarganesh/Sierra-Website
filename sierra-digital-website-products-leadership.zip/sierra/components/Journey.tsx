export default function Journey({ items }: { items: string[][] }) {
  return <ol className="mt-10 grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-6">{items.map(([t, d], i) => <li key={t} className="bg-white p-6"><span className="text-sm font-semibold text-accent">{i + 1}</span><h3 className="mt-2 font-semibold">{t}</h3><p className="mt-1 text-sm text-slate-600">{d}</p></li>)}</ol>;
}
