"use client";
import { useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { testimonials as T } from "@/lib/data";
export default function Testimonials() {
  const [i, setI] = useState(0), x = useRef(0), go = (d: number) => setI((i + d + T.length) % T.length), t = T[i];
  return <div role="region" aria-roledescription="carousel" aria-label="Client testimonials" tabIndex={0} onKeyDown={e => { if (e.key === "ArrowLeft") go(-1); if (e.key === "ArrowRight") go(1); }} onTouchStart={e => (x.current = e.touches[0].clientX)} onTouchEnd={e => { const d = e.changedTouches[0].clientX - x.current; if (Math.abs(d) > 50) go(d < 0 ? 1 : -1); }} className="rounded-2xl border-l-4 border-accent bg-white p-8 md:p-12">
    <blockquote aria-live="polite"><p className="text-xl font-medium leading-relaxed md:text-2xl">“{t.q}”</p><footer className="mt-6"><span className="font-semibold">{t.n}</span><span className="block text-slate-600">{t.r}, {t.c}</span></footer></blockquote>
    <div className="mt-8 flex items-center gap-3"><button aria-label="Previous testimonial" onClick={() => go(-1)} className="grid h-10 w-10 place-items-center border border-line hover:border-accent"><ChevronLeft size={18} /></button><button aria-label="Next testimonial" onClick={() => go(1)} className="grid h-10 w-10 place-items-center border border-line hover:border-accent"><ChevronRight size={18} /></button><span className="text-sm text-slate-500">{i + 1} / {T.length}</span></div></div>;
}
