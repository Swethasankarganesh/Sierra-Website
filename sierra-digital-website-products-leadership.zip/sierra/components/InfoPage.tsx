import { ExternalLink, Linkedin } from "lucide-react";
import { Btn, Container, PageHead, CTA } from "./ui";
import { leadership, partnersPage, aboutQuote, aboutInnovation, aboutAltitude, aboutPillars, aboutTimeline, statLabels } from "@/lib/data";
type D = { title: string; intro: string; ext: string; extLabel: string };
export default function InfoPage({ d, section, secHref, slug }: { d: D; section: string; secHref: string; slug: string }) {
  return <><PageHead crumbs={[{ t: section, href: secHref }, { t: d.title }]} title={d.title} intro={d.intro} img={slug === "about" ? "consulting" : undefined} />
    <section className="py-20 md:py-24"><Container className="space-y-14">
      {slug === "about" && <>
        <p className="max-w-3xl text-sm font-medium text-slate-500">— {aboutQuote.by}</p>
        <div className="grid gap-12 lg:grid-cols-2">{[aboutInnovation, aboutAltitude].map(b => <div key={b.h}><h2 className="text-3xl font-semibold tracking-tight">{b.h}</h2><div className="mt-5 space-y-4 text-slate-600">{b.p.map(t => <p key={t}>{t}</p>)}</div></div>)}</div>
        <ul className="grid gap-5 md:grid-cols-3">{aboutPillars.map(x => <li key={x.h} className="rounded-lg border border-line bg-mist p-6"><h3 className="text-xl font-semibold">{x.h}</h3><p className="mt-3 text-slate-600">{x.p}</p></li>)}</ul>
        <div><h2 className="text-3xl font-semibold tracking-tight">Sierra By The Numbers</h2><ul className="mt-6 flex flex-wrap gap-x-10 gap-y-3 text-slate-600">{statLabels.map(l => <li key={l} className="flex items-center gap-2"><span className="live-dot" aria-hidden />{l}</li>)}</ul></div>
        <div><h2 className="text-3xl font-semibold tracking-tight">Timeline of Sierra</h2><ol className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">{aboutTimeline.map(([y, t, d]) => <li key={y + t} className="rounded-lg border border-line bg-mist p-5"><p className="text-2xl font-semibold text-accent">{y}</p><h3 className="mt-1 font-semibold">{t}</h3><p className="mt-2 text-sm text-slate-600">{d}</p></li>)}</ol></div></>}
      {slug === "leadership" && <ul className="grid gap-x-8 gap-y-14 sm:grid-cols-2 lg:grid-cols-4">{leadership.map(([n, t, img, li]) => <li key={n} className="group">
          <div className="aspect-[4/5] overflow-hidden rounded-2xl border border-line bg-mist">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={img} alt={`${n}, ${t}`} width={480} height={600} loading="lazy" decoding="async" className="h-full w-full object-cover object-top transition-transform duration-500 group-hover:scale-105" /></div>
          <div className="mt-5 flex items-start justify-between gap-3"><div><h2 className="text-lg font-semibold leading-snug">{n}</h2><p className="mt-1 text-sm leading-snug text-slate-600">{t}</p></div><a href={li} target="_blank" rel="noopener noreferrer" aria-label={`${n} on LinkedIn`} className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-line text-slate-600 transition hover:border-accent hover:text-accent"><Linkedin size={16} /></a></div></li>)}</ul>}
      {slug === "partners" && <ul className="space-y-16">{partnersPage.partners.map((p, i) => <li key={p.name} className="grid items-center gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
          <div className={`flex h-48 items-center justify-center rounded-2xl border border-line bg-white p-10 ${i % 2 ? "lg:order-2" : ""}`}>{/* eslint-disable-next-line @next/next/no-img-element */}<img src={p.logo} alt={`${p.name} logo`} width={400} height={160} loading="lazy" decoding="async" className="max-h-full w-auto max-w-full object-contain" /></div>
          <div><h2 className="text-3xl font-semibold tracking-tight">{p.name}</h2><div className="mt-5 space-y-4 text-lg leading-relaxed text-slate-600">{p.paras.map(t => <p key={t}>{t}</p>)}</div>{p.cta && <a href={p.cta[1]} target="_blank" rel="noopener noreferrer" className="mt-7 inline-flex items-center gap-2 rounded-md border border-navy px-6 py-3 text-[15px] font-medium text-navy transition hover:bg-navy hover:text-white">{p.cta[0]}<ExternalLink size={15} aria-hidden /></a>}</div></li>)}</ul>}
      {(slug === "life-at-sierra" || slug === "careers") && <div><Btn href="/contact">{slug === "careers" ? "Get in touch about careers" : "Get in touch"}</Btn></div>}
      {slug === "about" && <div><Btn href="/contact">Get Started</Btn></div>}
    </Container></section><CTA /></>;
}
