/** Official "SAP Gold Partner" logo. Links to Sierra Digital's profile on SAP's partner site. */
export const SAP_PARTNER_URL = "https://www.sap.com/partners/profile/sierra-digital-inc#overview";
export default function SapPartnerBadge() {
  const W = 320, H = 300;
  return <a href={SAP_PARTNER_URL} target="_blank" rel="noopener noreferrer" aria-label="SAP Gold Partner: view Sierra Digital's profile on SAP (opens in a new tab)" className="inline-block rounded-lg transition hover:scale-[1.03] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent">
    {/* eslint-disable-next-line @next/next/no-img-element */}
    <img src="/images/sap-gold-partner.jpg" width={W} height={H} alt="SAP Gold Partner" className="h-28 w-auto md:h-32" decoding="async" />
  </a>;
}
