import type { Metadata } from "next";
import { SITE } from "./data";
export const meta = (title: string, description: string, path: string): Metadata => ({
  title, description, alternates: { canonical: `${SITE}${path}` },
  openGraph: { title, description, url: `${SITE}${path}`, siteName: "Sierra Digital", type: "website", images: [{ url: `${SITE}/images/og.jpg`, width: 1200, height: 630 }] },
});
