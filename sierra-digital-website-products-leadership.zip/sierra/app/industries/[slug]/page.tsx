import { notFound } from "next/navigation";
import Link from "next/link";
import { Container, Heading, PageHead, CTA, Btn } from "@/components/ui";
import ProcessFlow from "@/components/ProcessFlow";
import { industries, processes, solutions } from "@/lib/data";
import { meta } from "@/lib/meta";
export const dynamicParams = false;
export const generateStaticParams = () => industries.map(i => ({ slug: i.slug }));
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) { const { slug } = await params; const i = industries.find(x => x.slug === slug); return i ? meta(i.title, i.desc, `/industries/${slug}`) : {}; }
export default async function Page({ params }: P) {
  const { slug } = await params; const i = industries.find(x => x.slug === slug); if (!i) notFound();
  return <><PageHead crumbs={[{ t: "Industries", href: "/industries" }, { t: i.title }]} title={i.title} intro={i.desc} img={i.img} />
    <section className="py-16 md:py-20"><Container><Heading h="From industry to transformation" />{i.clients && <p className="mt-3 text-slate-600">Clients include {i.clients}.</p>}<div className="mt-8"><ProcessFlow label="Industry to transformation" steps={[i.title, "Business processes", "SAP + Data + AI + Cloud + Integration", "Connected transformation"]} /></div></Container></section>
    <section className="bg-mist py-16 md:py-20"><Container className="grid gap-10 lg:grid-cols-2"><div><h2 className="text-2xl font-semibold">Business processes</h2><ul className="mt-5 space-y-2">{processes.map(p => <li key={p.slug}><Link href={`/business-transformation/${p.slug}`} className="block rounded-lg border border-line bg-white px-4 py-3 hover:border-accent">{p.title}</Link></li>)}</ul></div><div><h2 className="text-2xl font-semibold">Solutions</h2><ul className="mt-5 space-y-2">{solutions.slice(0, 7).map(s => <li key={s.slug}><Link href={`/solutions/${s.slug}`} className="block rounded-lg border border-line bg-white px-4 py-3 hover:border-accent">{s.title}</Link></li>)}</ul></div></Container></section>
    <section className="py-10"><Container><Btn href="/contact">Talk to Our Experts</Btn></Container></section><CTA /></>;
}
