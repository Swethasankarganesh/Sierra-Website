import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Container, PageHead, CTA } from "@/components/ui";
import Photo from "@/components/Photo";
import { industries } from "@/lib/data";
import { meta } from "@/lib/meta";
export const metadata = meta("Industries", "Sierra Digital serves 12 industries including oil & gas, public sector, utilities, healthcare, retail and high tech.", "/industries");
export default function Page() { return <><PageHead crumbs={[{ t: "Industries" }]} title="Industry Expertise. Real-World Impact." intro="We understand your industry, your challenges and your opportunities." /><section className="py-20 md:py-24"><Container><ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">{industries.map(i => <li key={i.slug}><Link href={`/industries/${i.slug}`} className="group flex h-full flex-col overflow-hidden rounded-lg border border-line bg-white card-lift hover:border-accent hover:shadow-lg"><div className="overflow-hidden"><Photo name={i.img} sizes="(min-width:1024px) 33vw, 100vw" className="h-44 w-full object-cover transition-transform duration-500 group-hover:scale-105" /></div><div className="flex flex-1 flex-col p-6"><h2 className="text-lg font-semibold">{i.title}</h2><p className="mt-2 flex-1 text-sm text-slate-600">{i.desc}</p><ArrowRight size={16} className="mt-4 text-accent transition-transform group-hover:translate-x-1" /></div></Link></li>)}</ul></Container></section><CTA /></>; }
