import { Container, PageHead, CTA } from "@/components/ui";
import ProductCard from "@/components/ProductCard";
import { products } from "@/lib/data";
import { meta } from "@/lib/meta";
export const metadata = meta("Products", "EcoBridge, EnerBridge, HXM360, InFocus, OhZone and ORBit: purpose-built Sierra Digital products.", "/products");
export default function Page() { return <><PageHead crumbs={[{ t: "Products" }]} title="Purpose-Built Solutions for Real Business Outcomes" intro="Our products accelerate your transformation with industry-focused innovation." /><section className="py-24 md:py-28"><Container><ul className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 lg:gap-10">{products.map(p => <li key={p.slug}><ProductCard p={p} /></li>)}</ul></Container></section><CTA /></>; }
