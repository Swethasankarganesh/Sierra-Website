import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowRight, Check, ChevronRight, ExternalLink } from "lucide-react";
import { Btn, Container, CTA, Icon } from "@/components/ui";
import ProductCard from "@/components/ProductCard";
import { products, productPages } from "@/lib/data";
import { productBrand } from "@/data/productBrand";
import { meta } from "@/lib/meta";
export const dynamicParams = false;
export const generateStaticParams = () => products.map(p => ({ slug: p.slug }));
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) { const { slug } = await params; const p = products.find(x => x.slug === slug); return p ? meta(p.seoTitle, p.seoDesc, `/products/${slug}`) : {}; }

type Pair = [string, string, string?];
const Title = ({ id, children, sub }: { id?: string; children: React.ReactNode; sub?: string }) => <div className="max-w-3xl"><h2 id={id} className="text-3xl font-semibold tracking-tight md:text-4xl">{children}</h2>{sub && <p className="mt-5 text-lg leading-relaxed text-slate-600">{sub}</p>}</div>;
const Cards = ({ items, cols = "lg:grid-cols-3" }: { items: Pair[]; cols?: string }) => <ul className={`mt-12 grid gap-6 sm:grid-cols-2 ${cols}`}>{items.map(([h, d, img]) => <li key={h} className="flex flex-col overflow-hidden rounded-xl border border-line bg-white">{img && <div className="aspect-[16/10] bg-mist">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={img} alt={h} width={640} height={400} loading="lazy" decoding="async" className="h-full w-full object-cover" /></div>}<div className="p-7"><h3 className="text-lg font-semibold">{h}</h3><p className="mt-3 text-[15px] leading-relaxed text-slate-600">{d}</p></div></li>)}</ul>;

export default async function Page({ params }: P) {
  const { slug } = await params;
  const p = products.find(x => x.slug === slug), d = productPages[slug];
  if (!p || !d) notFound();
  const brand = productBrand[slug];
  const others = products.filter(x => x.slug !== slug);
  let n = 0; const bg = () => (n++ % 2 ? "bg-mist" : ""); // alternate section backgrounds in render order
  return <>
    {/* Hero: same structure on every product page */}
    <section className="relative isolate overflow-hidden bg-navy text-white">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={`/images/${p.img}-1600.webp`} srcSet={`/images/${p.img}-800.webp 800w, /images/${p.img}-1600.webp 1600w`} sizes="100vw" width={1600} height={900} alt="" aria-hidden fetchPriority="high" decoding="async" className="absolute inset-0 -z-20 h-full w-full object-cover" />
      <div aria-hidden className="absolute inset-0 -z-10 bg-gradient-to-r from-navy via-navy/90 to-navy/50" />
      <Container className="py-20 md:py-28">
        <nav aria-label="Breadcrumb" className="flex items-center gap-1 text-sm text-white/70"><Link href="/" className="hover:text-white">Home</Link><ChevronRight size={14} /><Link href="/products" className="hover:text-white">Products</Link><ChevronRight size={14} /><span className="text-white">{p.title}</span></nav>
        <div className="mt-10 flex items-center gap-4"><span className="grid h-14 w-14 place-items-center rounded-xl text-white shadow-lg" style={{ background: brand }}><Icon name={p.icon} size={26} /></span><span className="rounded-full border border-white/30 px-4 py-1.5 text-sm font-medium">{p.tag}</span></div>
        <h1 className="mt-8 max-w-4xl text-4xl font-semibold leading-[1.1] tracking-tight md:text-6xl">{d.h1}</h1>
        {d.tagline && <p className="mt-6 max-w-2xl text-xl text-white/90">{d.tagline}</p>}
        <p className="mt-6 max-w-3xl text-lg leading-relaxed text-white/80">{d.intro}</p>
        <div className="mt-10 flex flex-wrap gap-4"><Btn href="/contact">Get Started</Btn><Btn href="/products" variant="light">All Products</Btn></div>
      </Container>
    </section>

    {d.overviewH && <section className={`${bg()} py-24 md:py-28`}><Container><Title>{d.overviewH}</Title><div className="mt-8 max-w-3xl space-y-5 text-lg leading-relaxed text-slate-600">{d.overview.map((t: string) => <p key={t}>{t}</p>)}</div></Container></section>}

    {d.purposeH && <section className={`${bg()} py-24 md:py-28`}><Container><Title>{d.purposeH}</Title><p className="mt-6 max-w-3xl text-lg leading-relaxed text-slate-600">{d.purpose}</p></Container></section>}

    {d.showcase && <section className={`${bg()} py-24 md:py-28`}><Container><Title sub={d.showcaseIntro}>{d.showcaseH}</Title>
      <ul className="mt-14 space-y-16">{d.showcase.map((s: { tab: string; title: string; lead: string; bullets: string[]; img: string }, i: number) => <li key={s.title} className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
        <div className={i % 2 ? "lg:order-2" : ""}><p className="text-xs font-semibold tracking-[0.18em] text-accent">{s.tab.toUpperCase()}</p><h3 className="mt-3 text-2xl font-semibold tracking-tight">{s.title}</h3>{s.lead && <p className="mt-4 text-slate-600">{s.lead}</p>}<ul className="mt-5 space-y-3">{s.bullets.map(b => <li key={b} className="flex gap-3 text-slate-700"><Check size={18} className="mt-1 shrink-0 text-accent" aria-hidden />{b}</li>)}</ul></div>
        <div className="aspect-[16/10] overflow-hidden rounded-xl border border-line bg-white">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={s.img} alt={s.title} width={960} height={600} loading="lazy" decoding="async" className="h-full w-full object-contain" /></div>
      </li>)}</ul></Container></section>}

    {d.features && <section className={`${bg()} py-24 md:py-28`}><Container><Title sub={d.featuresIntro}>{d.featuresH ?? `Key Features of ${p.title}`}</Title><Cards items={d.features} /></Container></section>}

    {d.benefits && <section className={`${bg()} py-24 md:py-28`}><Container><Title sub={d.benefitsIntro}>{d.benefitsH ?? `Business Benefits of ${p.title}`}</Title>
      {d.note && <p className="mt-6 max-w-3xl text-slate-600">{d.note}</p>}
      <ol className="mt-12 grid gap-x-12 gap-y-8 md:grid-cols-2">{d.benefits.map(([h, t]: string[], i: number) => <li key={h} className="flex gap-5"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-accent text-sm font-semibold text-white">{i + 1}</span><div><h3 className="text-lg font-semibold">{h}</h3><p className="mt-2 text-[15px] leading-relaxed text-slate-600">{t}</p></div></li>)}</ol></Container></section>}

    {d.why && <section className={`${bg()} py-24 md:py-28`}><Container><Title sub={d.whyIntro}>{d.whyH ?? "Why Choose Sierra Digital?"}</Title><Cards items={d.why} /></Container></section>}

    {d.how && <section className={`${bg()} py-24 md:py-28`}><Container><Title>{d.howH ?? "How We Help"}</Title><div className="mt-8 max-w-3xl space-y-5 text-lg leading-relaxed text-slate-600">{d.how.map((t: string) => <p key={t}>{t}</p>)}</div>
      {d.external && <div className="mt-10"><a href={d.external[1]} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-md border border-navy px-6 py-3 text-[15px] font-medium text-navy transition hover:bg-navy hover:text-white">{d.external[0]}<ExternalLink size={15} aria-hidden /></a></div>}</Container></section>}

    {d.story && <section className={`${bg()} py-24 md:py-28`}><Container className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
      <div><h2 className="text-3xl font-semibold tracking-tight md:text-4xl">{d.story.h}</h2><p className="mt-6 text-lg leading-relaxed text-slate-600">{d.story.p}</p>
        {d.story.sub && <div className="mt-8 rounded-xl border border-line bg-mist p-7"><p className="text-xs font-semibold tracking-[0.18em] text-accent">SUCCESS STORY</p><h3 className="mt-3 text-xl font-semibold">{d.story.sub}</h3><p className="mt-3 text-[15px] leading-relaxed text-slate-600">{d.story.body}</p></div>}
        {d.story.links && <ul className="mt-8 flex flex-wrap gap-4">{d.story.links.map(([t, h]: string[]) => <li key={t}><a href={h} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-md bg-accent px-5 py-3 text-[15px] font-medium text-white transition hover:bg-brand">{t}<ExternalLink size={15} aria-hidden /></a></li>)}</ul>}</div>
      {(d.story.img || d.story.links) && <div className={d.story.links ? "grid grid-cols-2 gap-5" : ""}>{d.story.img ? <div className="aspect-[4/3] overflow-hidden rounded-xl border border-line bg-mist">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={d.story.img} alt="" width={960} height={720} loading="lazy" decoding="async" className="h-full w-full object-cover" /></div> : d.story.links.map(([t, , img]: string[]) => <div key={t} className="aspect-[3/4] overflow-hidden rounded-xl border border-line bg-mist">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={img} alt="" width={480} height={640} loading="lazy" decoding="async" className="h-full w-full object-cover" /></div>)}</div>}
    </Container></section>}

    <section className={`${bg()} py-24 md:py-28`}><Container><div className="flex flex-wrap items-end justify-between gap-6"><Title>Explore more Sierra Digital products</Title><Link href="/products" className="inline-flex items-center gap-1 text-sm font-medium text-accent hover:underline">View All Products<ArrowRight size={14} /></Link></div>
      <ul className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">{others.slice(0, 3).map(o => <li key={o.slug}><ProductCard p={o} /></li>)}</ul></Container></section>

    <CTA h={d.ctaH} p={d.ctaP} />
  </>;
}
