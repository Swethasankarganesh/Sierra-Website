import { Btn, Container, PageHead } from "@/components/ui";
import Link from "next/link";
import { SOURCE } from "@/lib/data";
import { meta } from "@/lib/meta";
export const metadata = meta("SAP AppHaus Houston – SAP Design Thinking Workshops", "Participate in SAP AppHaus design thinking workshops at Sierra Digital Houston to accelerate SAP adoption, reduce transformation risk, & build AI-ready enterprise solutions using human-centered innovation.", "/apphaus");
const IMG = "https://sierradigitalinc.com/wp-content/uploads/";
const features = [
  ["Plush lounge spaces", "We believe that comfort promotes productivity, and our comfortable interiors are sure to make your team feel right at home."],
  ["Artwork by local craftsmen", "Engaging art pieces by local craftmen and artisans reflect Houston’s rich cultural heritage throughout Sierra AppHaus Houston."],
  ["Modular work rooms with flexible layouts", "Sierra AppHaus Houston is furnished with modern, modular pieces that allow your team to rearrange and customize spaces in ways that make sense for your group."],
  ["Innovative modern appointments", "With innovative light fixtures, modern stylings, and a creative new approach to design, Sierra AppHaus Houston engages our instincts to play and create."],
  ["Fully stocked kitchen", "No-one works well on an empty stomach, and Sierra AppHaus Houston features a fully-stocked kitchen to feed innovation."],
];
const benefits = [
  ["Increased adoption and user satisfaction", "With more involvement in the process of solution design, your people are sure to adopt new technologies with heightened enthusiasm."],
  ["Quicker yield of tangible business value", "A natural consequence of increased adoption, solutions that involve users early in the design stage often yield value more quickly than their counterparts."],
  ["Accelerated development and implementation", "In the span of just a day, our workshops produce plans for a POC, accelerating the relief your organization needs."],
  ["Greater senses of innovation authority", "The Human-Centered Approach to Innovation places value on all the individuals who make your company special, and here, their needs and ambitions are reflected throughout solution design."],
  ["Heightened user experience", "By placing new value on the perspectives of SAP users, our design-thinking workshops produce solutions that make life easier for real people."],
];
const why = ["De-risk large SAP transformation programs", "Identify high-value AI and automation opportunities", "Improve adoption of SAP platforms", "Align business and IT stakeholders", "Validate use cases before funding implementation"];
const outcomes = ["Faster SAP adoption through early user involvement", "Clear, prioritized transformation roadmaps", "Reduced project risk", "Stronger alignment across leadership teams", "Production-ready proof-of-concept plans"];
const faqs = [
  ["What is Sierra Digital AppHaus?", "Sierra Digital AppHaus is an official SAP innovation space where organizations use design thinking workshops to validate transformation strategies, prioritize use cases, and accelerate SAP adoption."],
  ["How long does an AppHaus workshop take?", "Most workshops last 1–2 days, with longer engagements available for complex enterprise programs."],
  ["Is AppHaus only for SAP customers?", "No. Organizations exploring SAP, modernizing legacy environments, or evaluating AI-driven transformation can benefit from AppHaus workshops."],
  ["What happens during an SAP AppHaus workshop?", "A typical workshop includes stakeholder interviews, journey mapping, problem framing, rapid ideation, solution prototyping, use-case prioritization, and proof-of-concept planning."],
  ["When should you run an AppHaus workshop?", "Run an AppHaus workshop if your SAP program lacks business alignment, adoption risk is high, your AI strategy is unclear, too many use cases are competing for funding, or leadership needs a transformation roadmap."],
  ["Who should attend?", "AppHaus workshops are designed for CIOs and transformation leaders, business process owners, enterprise architects, innovation teams, and SAP platform leaders."],
  ["What are the outcomes of an AppHaus workshop?", "Typical outcomes include prioritized use cases, validated user needs, solution concepts, and a structured roadmap for proof-of-concept or implementation."],
  ["Why run AppHaus before starting an SAP program?", "Running AppHaus early reduces transformation risk, improves stakeholder alignment, and ensures investment is directed toward high-value initiatives."],
];
const Img = ({ src, alt, className = "" }: { src: string; alt: string; className?: string }) => /* eslint-disable-next-line @next/next/no-img-element */ <img src={`${IMG}${src}`} alt={alt} loading="lazy" className={`w-full rounded-xl object-cover ${className}`} />;
const List = ({ items }: { items: string[] }) => <ul className="mt-6 space-y-3">{items.map(i => <li key={i} className="flex gap-3 text-slate-700"><span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-accent" aria-hidden />{i}</li>)}</ul>;
export default function Page() {
  return <>
    <PageHead crumbs={[{ t: "AppHaus" }]} title="SAP AppHaus Houston Design Thinking Workshops" intro="Sierra Digital offers robust packages of customer success resources, which include assessments, enablement sessions, and design-thinking workshops hosted at Sierra AppHaus Houston, a newly-remodeled, creative space where our experts implement SAP’s Human-Centered Approach to Innovation (HCAI)." />
    <section className="py-16 md:py-20"><Container className="grid items-center gap-10 lg:grid-cols-2">
      <div><h2 className="text-3xl font-semibold tracking-tight">Sierra Digital AppHaus Houston - SAP Innovation Hub</h2><p className="mt-5 text-lg text-slate-600">Sierra Digital AppHaus Houston is an official SAP AppHaus innovation space where enterprises run design thinking workshops to accelerate SAP transformation, improve user adoption, and validate AI and digital initiatives before full-scale implementation.</p><div className="mt-8"><Btn href="/contact">Get Started</Btn></div></div>
      <Img src="2025/07/apphaus-sider.png" alt="AppHaus Network Partner" /></Container></section>

    <section className="bg-mist py-16 md:py-20"><Container className="grid items-center gap-10 lg:grid-cols-2">
      <Img src="2025/10/About-AppHaus.webp" alt="About AppHaus" />
      <div><h2 className="text-3xl font-semibold tracking-tight">What is Sierra Digital AppHaus?</h2>
        <p className="mt-5 text-slate-600">Sierra Digital AppHaus is an official member of the <a className="text-accent underline" href="https://apphaus.sap.com/network/houston" target="_blank" rel="noopener noreferrer">SAP AppHaus network</a> — a global ecosystem of innovation spaces designed to help organizations solve complex business challenges using SAP’s Human-Centered Approach to Innovation (HCAI).</p>
        <p className="mt-4 text-slate-600">At AppHaus Houston, business leaders, IT teams, and SAP users collaborate in structured workshops to identify high-value use cases, validate solution concepts, and align transformation priorities before investing in large-scale programs.</p></div></Container></section>

    <section className="py-16 md:py-20"><Container><h2 className="text-3xl font-semibold tracking-tight">Features</h2>
      <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{features.map(([t, d]) => <li key={t} className="rounded-lg border border-line bg-white p-6"><h3 className="text-lg font-semibold">{t}</h3><p className="mt-2 text-sm text-slate-600">{d}</p></li>)}</ul></Container></section>

    <section className="bg-mist py-16 md:py-20"><Container><h2 className="text-3xl font-semibold tracking-tight">Benefits</h2>
      <p className="mt-4 max-w-3xl text-slate-600">Visitors to the SAP AppHaus network and participants of HCAI design-thinking workshops often report:</p>
      <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{benefits.map(([t, d]) => <li key={t} className="rounded-lg border border-line bg-white p-6"><h3 className="text-lg font-semibold">{t}</h3><p className="mt-2 text-sm text-slate-600">{d}</p></li>)}</ul></Container></section>

    <section className="py-16 md:py-20"><Container className="grid gap-12 lg:grid-cols-2">
      <div><h2 className="text-2xl font-semibold tracking-tight">Why Enterprises Use AppHaus Before SAP Transformation</h2><p className="mt-4 text-slate-600">Organizations typically engage Sierra Digital AppHaus when they need to:</p><List items={why} /></div>
      <div><h2 className="text-2xl font-semibold tracking-tight">Business Outcomes of an AppHaus Workshop</h2><p className="mt-4 text-slate-600">Enterprises that participate in AppHaus workshops commonly achieve:</p><List items={outcomes} /></div></Container></section>

    <section className="bg-mist py-16 md:py-20"><Container className="grid items-center gap-10 lg:grid-cols-2">
      <div><h2 className="text-3xl font-semibold tracking-tight">Why Sierra Digital AppHaus?</h2>
        <p className="mt-5 text-slate-600">Sierra Digital combines deep SAP platform expertise with AI accelerators and industry frameworks to help enterprises move from ideation to executable transformation plans.</p>
        <p className="mt-4 text-slate-600">Our facilitators bring real-world experience across SAP modernization, <Link className="text-accent underline" href="/solutions/business-data-cloud">Business Data Cloud</Link>, AI adoption, and <a className="text-accent underline" href={`${SOURCE}/clean-core-assessment/`} target="_blank" rel="noopener noreferrer">Clean Core strategies</a> — ensuring workshops focus on measurable business outcomes rather than theoretical design.</p></div>
      <Img src="2025/07/apphaus-image-5.png" alt="Sierra Digital AppHaus" /></Container></section>

    <section className="py-16 md:py-20"><Container className="grid gap-12 lg:grid-cols-2">
      <div><h2 className="text-2xl font-semibold tracking-tight">About AppHaus Houston</h2><p className="mt-4 text-slate-600">Located in Houston, Texas, Sierra Digital AppHaus is a purpose-built innovation environment designed to promote collaboration, creativity, and rapid problem-solving.</p><p className="mt-4 text-slate-600">The space features modular workshop rooms, interactive collaboration zones, and flexible layouts that support immersive design thinking experiences.</p></div>
      <div><h2 className="text-2xl font-semibold tracking-tight">How AppHaus Reduces SAP Project Failure Risk</h2><p className="mt-4 text-slate-600">Organizations that invest in structured discovery and design before implementation are significantly more likely to achieve adoption, stay within budget, and realize transformation value faster. AppHaus enables this by validating business needs early and aligning stakeholders before execution begins.</p><p className="mt-4 text-slate-600">If your organization is exploring new approaches to solution design, or if you’re interested in visiting our beautiful new space, please contact <a className="text-accent underline" href="mailto:thrive@sierradigitalinc.com">thrive@sierradigitalinc.com</a> for an invitation to Sierra AppHaus Houston.</p></div></Container></section>

    <section className="bg-mist py-16 md:py-20"><Container className="max-w-3xl"><h2 className="text-3xl font-semibold tracking-tight">Frequently Asked Questions</h2>
      <div className="mt-8 divide-y divide-line rounded-lg border border-line bg-white">{faqs.map(([q, a]) => <details key={q} className="group p-5"><summary className="cursor-pointer list-none font-semibold">{q}</summary><p className="mt-3 text-slate-600">{a}</p></details>)}</div></Container></section>

    <section className="bg-gradient-to-b from-[#e6eefb] to-[#c5d6ee] py-20"><Container className="text-center"><h2 className="mx-auto max-w-2xl text-3xl font-semibold tracking-tight md:text-4xl">Experience Innovation at Sierra AppHaus Houston!</h2><p className="mt-4 text-slate-700">To start your journey toward transformative innovation!</p><div className="mt-8"><Btn href="/contact">Contact Us</Btn></div></Container></section>
  </>;
}
