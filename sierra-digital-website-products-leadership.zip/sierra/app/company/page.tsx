import Link from "next/link";
import { Container, PageHead, CTA } from "@/components/ui";
import { company } from "@/lib/data";
import { meta } from "@/lib/meta";
export const metadata = meta("Company", "About Sierra Digital: our story, leadership, careers and partners.", "/company");
export default function Page() { return <><PageHead crumbs={[{ t: "Company" }]} title="Company" intro="Altitude is an attitude. Founded in 2002." /><section className="py-20 md:py-24"><Container><div className="grid gap-5 md:grid-cols-2">{Object.entries(company).map(([k, v]) => <Link key={k} href={`/company/${k}`} className="block border border-line p-6 card-lift hover:border-accent hover:shadow-lg"><h2 className="text-lg font-semibold">{v.title}</h2><p className="mt-2 text-slate-600">{v.intro}</p></Link>)}</div></Container></section><CTA /></>; }
