import { notFound } from "next/navigation";
import InfoPage from "@/components/InfoPage";
import { company as data } from "@/lib/data";
import { meta } from "@/lib/meta";
export const dynamicParams = false;
export const generateStaticParams = () => Object.keys(data).map(slug => ({ slug }));
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) { const { slug } = await params; const d = data[slug]; return d ? meta(d.title, d.intro, "/company/" + slug) : {}; }
export default async function Page({ params }: P) { const { slug } = await params; const d = data[slug]; if (!d) notFound(); return <InfoPage d={d} section="Company" secHref="/company" slug={slug} />; }
