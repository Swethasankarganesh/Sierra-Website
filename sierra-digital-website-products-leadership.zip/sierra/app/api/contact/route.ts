import { NextResponse } from "next/server";
export async function POST(req: Request) {
  const d = await req.json().catch(() => null);
  if (!d?.name || !d?.email || !d?.company) return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
  if (d.website) return NextResponse.json({ ok: true }); // honeypot
  const url = process.env.CONTACT_WEBHOOK_URL;
  if (!url) return NextResponse.json({ error: "The form isn't connected to a destination yet. Set CONTACT_WEBHOOK_URL on the server." }, { status: 501 });
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(d) });
  return r.ok ? NextResponse.json({ ok: true }) : NextResponse.json({ error: "Could not deliver your request. Please try again." }, { status: 502 });
}
