"use client";
export default function Err({ reset }: { error: Error; reset: () => void }) { return <div className="mx-auto max-w-7xl px-5 py-28"><h1 className="text-4xl font-semibold">Something went wrong.</h1><p className="mt-4 text-slate-600">Try again, or return to the homepage.</p><button onClick={reset} className="mt-8 rounded-full bg-accent px-6 py-3 text-white">Try again</button></div>; }
