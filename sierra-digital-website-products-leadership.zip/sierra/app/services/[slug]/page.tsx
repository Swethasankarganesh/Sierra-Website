import { notFound } from "next/navigation";
import Link from "next/link";
import { Check } from "lucide-react";
import { Btn, Container, PageHead, CTA } from "@/components/ui";
import { services } from "@/lib/data";
import { meta } from "@/lib/meta";
export const dynamicParams = false;
export const generateStaticParams = () => services.map(s => ({ slug: s.slug }));
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) { const { slug } = await params; const s = services.find(x => x.slug === slug); return s ? meta(`${s.title} | SAP Services`, s.short, `/services/${slug}`) : {}; }
export default async function Page({ params }: P) {
  const { slug } = await params; const i = services.findIndex(x => x.slug === slug); if (i < 0) notFound(); const s = services[i];
  return <><PageHead crumbs={[{ t: "Services", href: "/services" }, { t: s.title }]} title={s.title} intro={s.short} />
    <section className="py-20 md:py-24"><Container><h2 className="text-2xl font-semibold">What&apos;s included</h2><ul className="mt-6 grid gap-3 md:grid-cols-2">{s.items.map(([t]) => <li key={t} className="flex items-center gap-3 rounded-lg border border-line bg-white p-5 font-medium"><Check size={18} className="shrink-0 text-accent" aria-hidden />{t}</li>)}</ul><div className="mt-10"><Btn href="/contact">Talk to Our Experts</Btn></div>
      <div className="mt-12 flex flex-wrap gap-3">{services.filter(x => x.slug !== slug).map(x => <Link key={x.slug} href={`/services/${x.slug}`} className="rounded-md border border-line px-4 py-2 hover:border-accent hover:text-accent">{x.n} {x.title}</Link>)}</div></Container></section><CTA /></>;
}
