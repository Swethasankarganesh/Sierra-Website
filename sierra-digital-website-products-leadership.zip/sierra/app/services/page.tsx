import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Container, PageHead, CTA, Icon } from "@/components/ui";
import { services } from "@/lib/data";
import { meta } from "@/lib/meta";
export const metadata = meta("Services", "Assess, Migrate, Transform and Run: Sierra Digital's SAP modernization lifecycle.", "/services");
export default function Page() { return <><PageHead crumbs={[{ t: "Services" }]} title="From Strategy to Impact" intro="A complete lifecycle of services to assess, migrate, transform and run your SAP and enterprise technology landscape." /><section className="py-20 md:py-24"><Container><ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{services.map(s => <li key={s.slug}><Link href={`/services/${s.slug}`} className="group flex h-full flex-col rounded-lg border border-line bg-mist p-6 card-lift hover:border-accent hover:shadow-lg"><div className="flex justify-between"><span className="text-3xl font-light text-slate-500">{s.n}</span><span className="text-accent"><Icon name={s.icon} /></span></div><h2 className="mt-6 text-xl font-semibold">{s.title}</h2><p className="mt-2 flex-1 text-sm text-slate-600">{s.short}</p><ArrowRight size={16} className="mt-5 text-accent" /></Link></li>)}</ul></Container></section><CTA /></>; }
