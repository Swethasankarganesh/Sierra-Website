import type { Metadata } from "next";
import "@fontsource-variable/inter";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { SITE } from "@/lib/data";
export const metadata: Metadata = { metadataBase: new URL(SITE), title: { default: "Sierra Digital | SAP Digital Transformation, AI & Data Solutions", template: "%s | Sierra Digital" }, openGraph: { images: [{ url: `${SITE}/images/og.jpg`, width: 1200, height: 630 }] }, description: "Sierra Digital delivers SAP digital transformation, AI-powered automation, data integration, and cloud solutions to help enterprises modernize, innovate, and drive smarter business outcomes." };
const ld = { "@context": "https://schema.org", "@type": "Organization", name: "Sierra Digital", url: SITE, foundingDate: "2002", description: "SAP digital transformation, AI-powered automation, data integration and cloud solutions.", sameAs: ["https://www.linkedin.com/company/sierra-digital", "https://www.facebook.com/sierradigital", "https://twitter.com/sierradigital", "https://www.instagram.com/sierradigitalinc", "https://www.youtube.com/@sierradigital"] };
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="en" ><body className="font-sans antialiased"><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} /><a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-white focus:p-3">Skip to content</a><Header /><main id="main">{children}</main><Footer /></body></html>;
}
