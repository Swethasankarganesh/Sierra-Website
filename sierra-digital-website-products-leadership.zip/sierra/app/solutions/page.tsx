import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Container, PageHead, CTA } from "@/components/ui";
import Photo from "@/components/Photo";
import { solutions, solutionImg } from "@/lib/data";
import { meta } from "@/lib/meta";
export const metadata = meta("Solutions", "SAP Business Suite, SAP BTP, Business Data Cloud, data & analytics, AI, cloud and integration from Sierra Digital.", "/solutions");
export default function Page() { return <><PageHead crumbs={[{ t: "Solutions" }]} title="Integrated Solutions for a Connected Enterprise" intro="From core SAP to cloud, data and AI, end-to-end solutions that help you transform, operate and grow with confidence." /><section className="py-20 md:py-24"><Container><ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{solutions.map(s => <li key={s.slug}><Link href={`/solutions/${s.slug}`} className="group block h-full overflow-hidden rounded-lg border border-line bg-white card-lift hover:shadow-lg"><div className="overflow-hidden"><Photo name={solutionImg[s.slug]} sizes="(min-width:1024px) 25vw, 50vw" className="h-32 w-full object-cover transition-transform duration-500 group-hover:scale-105" /></div><div className="p-5"><h2 className="font-semibold">{s.title}</h2><p className="mt-1 text-sm text-slate-600">{s.short}</p><ArrowRight size={16} className="mt-4 text-accent" /></div></Link></li>)}</ul></Container></section><CTA /></>; }
