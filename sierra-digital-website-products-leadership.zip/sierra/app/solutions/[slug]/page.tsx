import { notFound } from "next/navigation";
import Link from "next/link";
import { Btn, Container, Heading, PageHead, CTA, Icon } from "@/components/ui";
import { solutionImg } from "@/lib/data";
import ProcessFlow from "@/components/ProcessFlow";
import Cockpit from "@/components/Cockpit";
import { solutions, processes } from "@/lib/data";
import { meta } from "@/lib/meta";
export const dynamicParams = false;
export const generateStaticParams = () => solutions.map(s => ({ slug: s.slug }));
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) { const { slug } = await params; const s = solutions.find(x => x.slug === slug); return s ? meta(s.title, s.short, `/solutions/${slug}`) : {}; }
export default async function Page({ params }: P) {
  const { slug } = await params; const s = solutions.find(x => x.slug === slug); if (!s) notFound();
  const ld = { "@context": "https://schema.org", "@type": "Service", name: s.title, description: s.short, provider: { "@type": "Organization", name: "Sierra Digital" } };
  return <><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
    <PageHead crumbs={[{ t: "Technology", href: "/solutions" }, { t: s.title }]} title={s.title} intro={s.short} img={solutionImg[s.slug]} />
    <section className="py-16 md:py-20"><Container><Heading h="From business need to outcome" /><div className="mt-8"><ProcessFlow label="Business need to outcome" steps={[s.need, "Business process", s.title, "Intelligent automation", s.outcome]} /></div></Container></section>
    <section className="bg-mist py-16 md:py-20"><Container className="grid gap-10 lg:grid-cols-3"><div className="lg:col-span-2"><h2 className="text-2xl font-semibold">Key capabilities</h2><ul className="mt-6 space-y-3">{s.points.map(p => <li key={p} className="flex gap-3 rounded-2xl rounded-lg border border-line bg-white p-4"><span className="text-accent"><Icon name="Check" size={20} /></span>{p}</li>)}</ul></div><aside className="h-fit rounded-2xl rounded-lg border border-line bg-white p-7 md:p-8"><h2 className="font-semibold">Talk to our experts</h2><p className="mt-2 text-slate-600">Tell us which process you want to improve.</p><div className="mt-5 flex flex-col items-start gap-3"><Btn href="/contact">Talk to Our Experts</Btn></div></aside></Container></section>
    {s.slug === "ai-rise-cockpit" && <Cockpit />}
    <section className="py-16 md:py-20"><Container><h2 className="text-2xl font-semibold">Processes this supports</h2><ul className="mt-6 flex flex-wrap gap-3">{processes.map(p => <li key={p.slug}><Link href={`/business-transformation/${p.slug}`} className="block rounded-2xl border border-line bg-white px-4 py-2 hover:border-accent hover:text-accent">{p.title}</Link></li>)}</ul></Container></section><CTA /></>;
}
