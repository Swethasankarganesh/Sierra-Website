import Link from "next/link";
import { Btn, Container, PageHead, CTA } from "@/components/ui";
import { testimonials, clients } from "@/lib/data";
import { meta } from "@/lib/meta";
export const metadata = meta("Customer Stories", "Enterprise teams describe working with Sierra Digital.", "/case-studies");
export default function Page() { return <><PageHead crumbs={[{ t: "Customer stories" }]} title="Real Results. Lasting Impact." intro="Enterprise teams describe working with Sierra in their own words." /><section className="py-20 md:py-24"><Container><ul className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{testimonials.map(t => <li key={t.slug}><Link href={`/case-studies/${t.slug}`} className="flex h-full flex-col rounded-lg border border-line bg-white p-6 card-lift hover:border-accent hover:shadow-lg"><p className="text-sm font-semibold text-accent">{t.c}</p><blockquote className="mt-3 flex-1 text-lg">“{t.q}”</blockquote><p className="mt-5 font-semibold">{t.n}</p><p className="text-sm text-slate-600">{t.r}</p></Link></li>)}</ul><p className="mt-10 text-slate-600">Our valued clients: {clients.join(" · ")}</p></Container></section><CTA /></>; }
