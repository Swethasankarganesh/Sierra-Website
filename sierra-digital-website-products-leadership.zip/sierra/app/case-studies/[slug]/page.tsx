import { notFound } from "next/navigation";
import { Btn, Container, PageHead, CTA } from "@/components/ui";
import { testimonials } from "@/lib/data";
import { meta } from "@/lib/meta";
export const dynamicParams = false;
export const generateStaticParams = () => testimonials.map(t => ({ slug: t.slug }));
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) { const { slug } = await params; const t = testimonials.find(x => x.slug === slug); return t ? meta(`${t.c}: customer story`, t.q.slice(0, 150), `/case-studies/${slug}`) : {}; }
export default async function Page({ params }: P) {
  const { slug } = await params; const t = testimonials.find(x => x.slug === slug); if (!t) notFound();
  return <><PageHead crumbs={[{ t: "Customer stories", href: "/case-studies" }, { t: t.c }]} title={t.c} intro="In their own words." /><section className="py-20 md:py-24"><Container className="max-w-3xl"><blockquote className="border-l-4 border-accent pl-6 text-2xl font-medium leading-relaxed md:text-3xl">“{t.q}”</blockquote><p className="mt-6 font-semibold">{t.n}</p><p className="text-slate-600">{t.r}, {t.c}</p><div className="mt-10 flex flex-wrap gap-3"><Btn href="/case-studies" variant="secondary">All customer stories</Btn></div></Container></section><CTA /></>;
}
