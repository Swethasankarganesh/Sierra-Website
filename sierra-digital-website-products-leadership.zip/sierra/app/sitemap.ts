import type { MetadataRoute } from "next";
import { SITE, products, solutions, services, industries, articles, company, processes, testimonials } from "@/lib/data";
export default function sitemap(): MetadataRoute.Sitemap {
  const p = ["", "/solutions", "/services", "/products", "/industries", "/insights", "/case-studies", "/business-transformation", "/business-transformation/processes", "/company", "/apphaus", "/contact", "/legal/privacy", "/legal/terms", "/legal/cookies",
    ...products.map(x => `/products/${x.slug}`), ...solutions.map(s => `/solutions/${s.slug}`), ...services.map(s => `/services/${s.slug}`), ...industries.map(i => `/industries/${i.slug}`), ...articles.map(a => `/insights/${a.slug}`), ...testimonials.map(t => `/case-studies/${t.slug}`), ...processes.map(x => `/business-transformation/${x.slug}`), ...Object.keys(company).map(k => `/company/${k}`)];
  return p.map(x => ({ url: SITE + x }));
}
