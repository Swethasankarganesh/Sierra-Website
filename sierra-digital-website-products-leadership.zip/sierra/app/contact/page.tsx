import { Container, PageHead } from "@/components/ui";
import ContactForm from "@/components/ContactForm";
import { meta } from "@/lib/meta";
export const metadata = meta("Contact", "Book a free discovery call with a Sierra Digital SAP architect.", "/contact");
export default function Page() { return <><PageHead crumbs={[{ t: "Contact" }]} title="Let&apos;s transform what&apos;s next." intro="Tell us about the business process you want to improve." /><section className="py-20 md:py-24"><Container className="max-w-3xl"><ContactForm /></Container></section></>; }
