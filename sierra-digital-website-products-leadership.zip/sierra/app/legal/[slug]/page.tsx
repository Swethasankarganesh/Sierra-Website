import { notFound } from "next/navigation";
import { Btn, Container, PageHead } from "@/components/ui";
import { SOURCE } from "@/lib/data";
import { meta } from "@/lib/meta";
const L: Record<string, [string, string]> = { privacy: ["Privacy policy", "/privacy-policy/"], terms: ["Terms of service", "/terms-of-service/"], cookies: ["Cookie policy", "/cookie-policy/"] };
export const dynamicParams = false;
export const generateStaticParams = () => Object.keys(L).map(slug => ({ slug }));
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) { const { slug } = await params; const l = L[slug]; return l ? meta(l[0], `Sierra Digital ${l[0].toLowerCase()}.`, "/legal/" + slug) : {}; }
export default async function Page({ params }: P) { const { slug } = await params; const l = L[slug]; if (!l) notFound(); return <><PageHead crumbs={[{ t: l[0] }]} title={l[0]} intro="The official policy text is maintained on the Sierra Digital site." /><section className="py-20 md:py-24"><Container><Btn href={SOURCE + l[1]}>Read the {l[0].toLowerCase()}</Btn></Container></section></>; }
