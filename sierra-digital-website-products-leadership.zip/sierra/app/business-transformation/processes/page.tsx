import Link from "next/link";
import { Container, PageHead, CTA } from "@/components/ui";
import { processes } from "@/lib/data";
import { meta } from "@/lib/meta";
export const metadata = meta("Business Processes", "Order to Cash, Procure to Pay, Record to Report and more: business processes Sierra Digital transforms.", "/business-transformation/processes");
export default function Page() { return <><PageHead crumbs={[{ t: "Business Transformation", href: "/business-transformation" }, { t: "Processes" }]} title="Business processes" intro="Transform the processes that drive your business." /><section className="py-20 md:py-24"><Container><div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{processes.map(p => <Link key={p.slug} href={`/business-transformation/${p.slug}`} className="block rounded-2xl border border-line bg-white p-6 card-lift hover:border-accent hover:shadow-lg"><h2 className="text-lg font-semibold">{p.title}</h2><p className="mt-1 text-slate-600">{p.span}</p><p className="mt-4 text-sm text-slate-500">{p.steps.join(" → ")}</p></Link>)}</div></Container></section><CTA /></>; }
