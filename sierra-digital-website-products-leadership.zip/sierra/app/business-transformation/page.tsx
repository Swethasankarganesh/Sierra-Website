import { Container, Heading, PageHead, CTA, Btn } from "@/components/ui";
import Journey from "@/components/Journey";
import ProcessFlow from "@/components/ProcessFlow";
import { journey, framework } from "@/lib/data";
import { meta } from "@/lib/meta";
export const metadata = meta("Business Transformation", "How Sierra Digital transforms business processes with SAP, AI, data, cloud and integration.", "/business-transformation");
const q = [["What business process is involved?", "For example, Order to Cash."], ["What is going wrong?", "Manual work, disconnected systems, slow approvals, poor visibility."], ["What technology can improve it?", "SAP, AI, automation, integration, data and analytics."], ["How does Sierra transform it?", "Through a structured transformation journey."], ["What outcome can be achieved?", "Faster processes, better visibility, less manual effort."]];
export default function Page() { return <><PageHead crumbs={[{ t: "Business Transformation" }]} title="Transform business processes. Enable intelligent enterprises." intro="Sierra starts with the business problem, then applies SAP, AI, data, cloud and integration to solve it." img="consulting" />
  <section className="py-20 md:py-24"><Container><Heading h="From business problem to business outcome." /><div className="mt-10"><ProcessFlow label="Transformation flow" steps={["Business problem", "Process", "Data", "SAP", "AI", "Automation", "Insight", "Business outcome"]} /></div></Container></section>
  <section className="bg-mist py-20 md:py-24"><Container><Heading h="Sierra's approach" /><Journey items={journey} /></Container></section>
  <section className="py-20 md:py-24"><Container><Heading h="One transformation framework. Multiple business outcomes." /><Journey items={framework} /></Container></section>
  <section className="bg-mist py-20 md:py-24"><Container><Heading h="Every solution answers five questions." /><ol className="mt-8 grid gap-4 md:grid-cols-5">{q.map(([t, d], i) => <li key={t} className="rounded-2xl border-t-4 border-accent bg-white p-6"><span className="text-sm font-semibold text-accent">{i + 1}</span><h3 className="mt-1 font-semibold">{t}</h3><p className="mt-1 text-sm text-slate-600">{d}</p></li>)}</ol><div className="mt-10"><Btn href="/business-transformation/processes">Explore business processes</Btn></div></Container></section><CTA /></>; }
