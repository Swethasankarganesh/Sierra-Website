import { notFound } from "next/navigation";
import Link from "next/link";
import { Container, Heading, PageHead, CTA } from "@/components/ui";
import ProcessFlow from "@/components/ProcessFlow";
import { processes, solutions } from "@/lib/data";
import { meta } from "@/lib/meta";
export const dynamicParams = false;
export const generateStaticParams = () => processes.map(p => ({ slug: p.slug }));
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) { const { slug } = await params; const p = processes.find(x => x.slug === slug); return p ? meta(`${p.title} Transformation`, `${p.span} How Sierra Digital transforms ${p.title} with SAP, AI, data, cloud and integration.`, `/business-transformation/${slug}`) : {}; }
export default async function Page({ params }: P) {
  const { slug } = await params; const p = processes.find(x => x.slug === slug); if (!p) notFound();
  const tech = solutions.filter(s => s.slug !== "ai-rise-cockpit").slice(0, 6);
  return <><PageHead crumbs={[{ t: "Business Transformation", href: "/business-transformation" }, { t: "Processes", href: "/business-transformation/processes" }, { t: p.title }]} title={`${p.title} transformation`} intro={p.span} />
    <section className="py-16 md:py-20"><Container><Heading h="The business process" /><div className="mt-8"><ProcessFlow label={`${p.title} process`} steps={p.steps} /></div></Container></section>
    <section className="bg-mist py-16 md:py-20"><Container><Heading h="What often goes wrong" sub="Common patterns in this process, not results from a specific client." /><ul className="mt-8 grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-5">{p.pains.map(x => <li key={x} className="bg-white p-5 font-medium">{x}</li>)}</ul></Container></section>
    <section className="py-16 md:py-20"><Container><Heading h="Technology enablement" sub={p.evidence ?? "Where Sierra's capabilities apply to this process."} /><div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">{tech.map(s => <Link key={s.slug} href={`/solutions/${s.slug}`} className="block rounded-2xl border border-line bg-white p-5 transition hover:border-accent"><h3 className="font-semibold">{s.title}</h3><p className="mt-1 text-sm text-slate-600">{s.short}</p></Link>)}</div></Container></section>
    <section className="bg-mist py-16 md:py-20"><Container><Heading h="Transformation architecture" /><div className="mt-8"><ProcessFlow label="Transformation architecture" steps={["Process", "Applications", "Integration", "Data", "Intelligence", "Automation"]} /></div></Container></section>
    <section className="py-16 md:py-20"><Container><Heading h="Business impact" sub="The kinds of outcome this transformation targets." /><ul className="mt-8 grid gap-4 md:grid-cols-4">{p.outcomes.map(o => <li key={o} className="rounded-2xl border-t-4 border-accent bg-white p-5 font-medium">{o}</li>)}</ul></Container></section><CTA /></>;
}
