import { notFound } from "next/navigation";
import { Btn, Container, PageHead, CTA } from "@/components/ui";
import { articles, SOURCE } from "@/lib/data";
import { meta } from "@/lib/meta";
export const dynamicParams = false;
export const generateStaticParams = () => articles.map(a => ({ slug: a.slug }));
type P = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: P) { const { slug } = await params; const a = articles.find(x => x.slug === slug); return a ? meta(a.title, a.excerpt, `/insights/${slug}`) : {}; }
export default async function Page({ params }: P) {
  const { slug } = await params; const a = articles.find(x => x.slug === slug); if (!a) notFound();
  return <><PageHead crumbs={[{ t: "Resources", href: "/insights" }, { t: a.kind === "Article" ? "Blog" : a.kind + "s" }]} title={a.title} intro={a.kind === "Article" ? `Blog${a.date ? ` · ${a.date}` : ""}` : `${a.group} ${a.kind}${a.date ? ` · ${a.date}` : ""}`} /><section className="py-20 md:py-24"><Container className="max-w-3xl"><p className="text-xl text-slate-600">{a.excerpt}</p><div className="mt-8"><Btn href={`${SOURCE}${a.ext}`}>{a.cta}</Btn></div></Container></section><CTA /></>;
}
