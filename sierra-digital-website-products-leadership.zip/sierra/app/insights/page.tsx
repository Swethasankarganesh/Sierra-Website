import Link from "next/link";
import { Container, PageHead, CTA } from "@/components/ui";
import { articles } from "@/lib/data";
import { meta } from "@/lib/meta";
import type { Article } from "@/data/insights";
export const metadata = meta("Resources", "Blog posts, events and webinars from Sierra Digital on SAP, data, AI and cloud.", "/insights");
const Card = ({ a }: { a: Article }) => <li><Link href={`/insights/${a.slug}`} className="flex h-full flex-col rounded-lg border border-line bg-white p-6 card-lift hover:border-accent hover:shadow-lg"><p className="text-xs font-semibold tracking-[0.15em] text-accent">{a.kind.toUpperCase()}</p><h3 className="mt-3 text-xl font-semibold">{a.title}</h3>{a.date && <p className="mt-1 text-sm text-slate-500">{a.date}</p>}<p className="mt-3 flex-1 text-slate-600">{a.excerpt}</p><span className="mt-4 font-medium text-accent">{a.cta} →</span></Link></li>;
const Block = ({ title, items, empty }: { title: string; items: Article[]; empty?: string }) => <div className="mt-14 first:mt-0"><h2 className="text-2xl font-semibold tracking-tight">{title}</h2>{items.length ? <ul className="mt-6 grid gap-5 md:grid-cols-2">{items.map(a => <Card key={a.slug} a={a} />)}</ul> : <p className="mt-4 text-slate-600">{empty}</p>}</div>;
const pick = (kind: Article["kind"], group: Article["group"]) => articles.filter(a => a.kind === kind && a.group === group);
export default function Page() { return <><PageHead crumbs={[{ t: "Resources" }]} title="Resources" intro="Blog posts, events and webinars from Sierra Digital." /><section className="py-20 md:py-24"><Container>
  <Block title="Blog" items={pick("Article", "Blog")} />
  <Block title="Upcoming Events" items={pick("Event", "Upcoming")} empty="New events coming soon.." />
  <Block title="Past Events" items={pick("Event", "Past")} />
  <Block title="Upcoming Webinars" items={pick("Webinar", "Upcoming")} empty="New webinars coming soon.." />
  <Block title="Past Webinars" items={pick("Webinar", "Past")} />
  </Container></section><CTA /></>; }
