// Distinct logo-mark colors per product (no real brand asset exists to hotlink, so each gets a designed mark).
export const productBrand: Record<string, string> = {
  ecobridge: "#2f9e5a", enerbridge: "#e6a23c", hxm360: "#8a5cf6", infocus: "#1a6df0", ohzone: "#16a3a3", orbit: "#e2496b",
};
