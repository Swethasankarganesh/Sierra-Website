export type Info = { title: string; intro: string; ext: string; extLabel: string };
export const insights: Record<string, Info> = {
 blog: { title: "Blog", intro: "Sierra's articles on SAP, AI and data.", ext: "/blog/", extLabel: "Read the Sierra blog" },
 "success-stories": { title: "Success Stories", intro: "How enterprise teams work with Sierra.", ext: "/success-stories/", extLabel: "Read success stories" },
 testimonials: { title: "Testimonials", intro: "What clients say about working with Sierra.", ext: "/testimonials/", extLabel: "See all testimonials" },
 news: { title: "News", intro: "Company news and announcements from Sierra Digital.", ext: "/news/", extLabel: "Read the latest news" },
 events: { title: "Events", intro: "Where to meet the Sierra team.", ext: "/events/", extLabel: "See upcoming events" },
 webinars: { title: "Webinars", intro: "Sessions with Sierra's SAP architects.", ext: "/webinars/", extLabel: "Browse webinars" },
};
export const company: Record<string, Info> = {
 about: { title: "About Us", intro: "At Sierra, our goal is to simplify, extend, and enhance SAP technology as a means of optimizing its value.", ext: "/about-us/", extLabel: "Read our full story" },
 leadership: { title: "Leadership Team", intro: "Meet the experienced leaders guiding Sierra Digital’s SAP innovation, cloud transformation and data-driven enterprise solutions.", ext: "/leadership-teams/", extLabel: "Meet the leadership team" },
 partners: { title: "Partners & Alliances", intro: "It’s not uncommon for a mid-sized technology consulting firm to pair with platform partners. What is unusual is for a firm to partner as deeply and broadly as we do.", ext: "/partners-and-alliances/", extLabel: "View partners and alliances" },
 "life-at-sierra": { title: "Life at Sierra", intro: "What it's like working at Sierra Digital.", ext: "/life-at-sierra/", extLabel: "See life at Sierra" },
 careers: { title: "Careers", intro: "Join a team that helps enterprises reach higher.", ext: "/careers/", extLabel: "See open roles" },
};
export const timeline = [["2002", "Sierra Digital is founded."], ["Today", "SAP Gold Partner and BTP & AI Innovation Station."], ["AppHaus", "Sierra AppHaus: a hub for innovation."], ["Latest", "Sierra Digital invests in Smartsoft, strengthening SAP expertise."]];
