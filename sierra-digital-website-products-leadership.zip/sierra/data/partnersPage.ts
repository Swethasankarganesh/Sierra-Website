// Real content from sierradigitalinc.com/partners-and-alliances/.
export const partnersPage = {
 "h1": "Value To You, Is Evident In Our Partnerships",
 "intro": "It’s not uncommon for a mid-sized technology consulting firm to pair with platform partners. What is unusual is for a firm to partner as deeply and broadly as we do.",
 "partners": [
  {
   "name": "SAP",
   "logo": "https://sierradigitalinc.com/wp-content/uploads/2025/07/sap-logo.png",
   "paras": [
    "Since 2002, Sierra Digital has served as a pure-play staffing and implementation partner to SAP. As a result, we have amassed an unparalleled reservoir of knowledge led by certified on-staff experts.",
    "Leveraging our flourishing standing as an SAP Silver Partner, we continue to develop new and exciting innovations that further accelerate, automate and extend the power of SAP technology to deliver transformational business outcomes."
   ],
   "cta": [
    "Learn More",
    "https://partnerfinder.sap.com/profile/0000970184"
   ]
  },
  {
   "name": "AWS",
   "logo": "https://sierradigitalinc.com/wp-content/uploads/2025/07/aws-logo.png",
   "paras": [
    "Sierra Digital is a proud partner to AWS, leveraging our combined resources to promote customer success and drive business value with powerful cloud technologies.",
    "As the world’s leading hyperscaler, AWS provides secure, reliable service to millions of customers, and with our domain expertise in SAP, Sierra Digital provides the focused insight that SAP customers on AWS need to enact meaningful change. Find Sierra Digital’s solutions on the AWS Marketplace today."
   ],
   "cta": [
    "Learn More",
    "https://aws.amazon.com/marketplace/seller-profile?id=seller-zx7v5w3wesf24"
   ]
  },
  {
   "name": "Microsoft",
   "logo": "https://sierradigitalinc.com/wp-content/uploads/2025/07/microsoft-logo.png",
   "paras": [
    "Microsoft offers the trusted path to enterprise-ready innovation in the cloud—bringing the intelligence, security, and reliability of Azure to your SAP applications.",
    "At Sierra Digital, we partner with Microsoft and SAP to help companies migrate to the Azure Cloud. As an example, our BlueSky solution offers an increased ability for organizations to rapidly spin up instances, delivering capabilities to business faster, with the agility and flex of Microsoft’s secure infrastructure and business software."
   ]
  },
  {
   "name": "Databricks",
   "logo": "https://sierradigitalinc.com/wp-content/uploads/2025/12/Databricks_Logo-1024x538.png",
   "paras": [
    "Sierra + Databricks: Accelerating Data & AI Innovation – Sierra partners with Databricks to help enterprises unlock the full power of data and AI. By combining Sierra’s domain expertise with Databricks’ unified analytics platform, we enable organizations to move faster, smarter, and with measurable impact.",
    "From joint industry events to Proof of Concepts like Capital Project Controls for a leading client, our collaboration is delivering real results—and continuously shaping new use cases and innovations."
   ]
  }
 ]
};
