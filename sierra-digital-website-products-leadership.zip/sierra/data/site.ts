export const SITE = process.env.NEXT_PUBLIC_SITE_URL ?? "https://sierradigitalinc.com";
export const SOURCE = "https://sierradigitalinc.com";
export const LOGO = { src: `${SOURCE}/wp-content/uploads/2025/06/Single-line-multi-1024x135.png`, white: `${SOURCE}/wp-content/uploads/2025/06/Single-line-White-scaled.png`, w: 1024, h: 135 };
// The real site's counters (Years / Delivery Centers / Consultants / Active clients / Successful SAP
// Implementations) render as JS-animated numbers starting from 0 in the page source — the true figures
// aren't in the static HTML, so we show the categories without inventing numbers.
export const statLabels = ["Years", "Delivery Centers", "Consultants", "Active Clients", "Successful SAP Implementations"];
export const clients = ["Twitch", "Metro", "Lexmark", "New York Housing Authority", "Exxon", "Energy Transfer", "ConocoPhillips", "City of Houston", "San Diego", "Palo Alto"];
// Real client logo files, hotlinked from Sierra's own site (same "Our Valued Clients" strip on sierradigitalinc.com).
export const clientLogos: Record<string, string> = {
  "Twitch": "twitch-img.webp", "Metro": "metro-img.webp", "Lexmark": "lexmark-logo.webp",
  "New York Housing Authority": "Newyork-housing-authority.webp", "Exxon": "exxon.webp",
  "Energy Transfer": "energy-transfer-img.webp", "ConocoPhillips": "conoco-phillips.webp",
  "City of Houston": "city-of-houston-1.webp", "San Diego": "san-diego-1.webp", "Palo Alto": "palo-alto.webp",
};
export const clientLogoBase = `${SOURCE}/wp-content/uploads/2025/10/`;
export const social = [
  ["LinkedIn", "https://www.linkedin.com/company/sierradigital/"],
  ["Facebook", "https://www.facebook.com/SierraDigitalInc"],
  ["X", "https://x.com/sierra_digital"],
  ["Instagram", "https://www.instagram.com/sierra_digital/"],
  ["YouTube", "https://www.youtube.com/@sierradigital"],
];
export const partners = ["SAP", "AWS", "Microsoft", "Google"];
export const aboutBlurb = "As SAP's BTP & AI Innovation Station, Sierra is your partner in extending and personalizing SAP systems with cutting-edge cloud technology. We leverage powerful tools like AI, automation, and advanced analytics to help businesses enhance their operations. By connecting processes and simplifying workflows, we enable organizations to unlock new insights, optimize decision-making, and drive competitive advantage.";
export const testimonials = [
 { slug: "nestoil", q: "The can-do mentality comes through in Sierra's culture. There are not that many parties which have the capability to serve a project like ours across the globe.", n: "Dr. Ernest", r: "Founder", c: "Nestoil" },
 { slug: "andeavor-marathon", q: "Sierra has strong expertise in all of the SAP modules. They have strong project leadership skills and they bring a very good long-term commitment to the efforts within SAP.", n: "Mohan Dasappan", r: "Run Support Manager", c: "Andeavor / Marathon" },
 { slug: "schlumberger", q: "I believe Sierra is a differentiated system integration firm from the standpoint that the resources, capabilities, delivery and flexibility are excellent. Sierra Digital is always there to help us, whatever our needs are.", n: "Arun Shanmugam", r: "Architect", c: "Schlumberger" },
 { slug: "houston-oil-gas", q: "With the help of Sierra Digital, all our SAP systems can have a direct connection with SAP Analytics Cloud. This really streamlines the business process of data retrieval and display when compared to other non-native BI tools.", n: "IT Director", r: "IT Director", c: "Houston-based Oil & Gas company" },
 { slug: "sap-labs", q: "Sierra cloud readiness apps help you know before you go, and help you know how to grow.", n: "Ron Chermin", r: "Senior Director", c: "SAP Labs" },
 { slug: "sap-btp-everywhere", q: "Cross-industry BTP apps pioneered by Sierra are game-changers.", n: "Dave Maloney", r: "VP, BTP Everywhere", c: "SAP" },
];
