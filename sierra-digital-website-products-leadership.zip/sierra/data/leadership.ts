// Real leadership team from sierradigitalinc.com/leadership-teams/ (name, title, photo, LinkedIn).
export const leadership: [string, string, string, string][] = [
 [
  "Senthil Kumar",
  "Chairman & CEO",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/Senthil-Kumar-ceo.webp",
  "https://www.linkedin.com/in/senthil-kumar-998834/"
 ],
 [
  "Sudhakar Virupakshi",
  "Chief Technology Officer",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/sudhakar.webp",
  "https://www.linkedin.com/in/sudhakar-virupakshi-60b60a5"
 ],
 [
  "Maya Bava",
  "Chief Operating Officer",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/Maya-Bava-COO.webp",
  "https://www.linkedin.com/in/maya-bava-8b0b743/"
 ],
 [
  "Narasimman L. Madhavarao",
  "Chief Product & Transformation Officer",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/narasimman.webp",
  "https://www.linkedin.com/in/mlnaras/"
 ],
 [
  "Stacy Wilson",
  "Regional Vice President",
  "https://sierradigitalinc.com/wp-content/uploads/2026/07/stacy.png",
  "https://www.linkedin.com/in/stacy-wilson-9a7a0b/"
 ],
 [
  "Karl Schmidt",
  "Vice President – Oil & Gas Advisory",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/Karl-Schmidt-VP-Oil-Gas.webp",
  "https://www.linkedin.com/in/karlrschmidt777/"
 ],
 [
  "Sriman Narayanan Sundararaman",
  "Vice President – Sales",
  "https://sierradigitalinc.com/wp-content/uploads/2026/02/MicrosoftTeams-image-45-1.jpg",
  "https://www.linkedin.com/in/srimannarayanan/"
 ],
 [
  "TC Venkatesan",
  "Senior Director – Innovation Advisory",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/TC-Venkatesan.webp",
  "https://www.linkedin.com/in/venkatesan-thoddu-chandraiyer-b263086/"
 ],
 [
  "Scott Gabelhart",
  "Senior Director – Data Strategy & Innovation",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/Scott-Gabelhart.webp",
  "https://www.linkedin.com/in/scott-gabelhart/"
 ],
 [
  "Sameel Baker",
  "Senior Director, Global Head of Product & Cloud Platforms",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/sameel-baker.webp",
  "https://www.linkedin.com/in/sameel-baker/"
 ],
 [
  "Rajan Marathe",
  "Director Business Intelligence",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/Rajan-Marathae.webp",
  "https://www.linkedin.com/in/rajanmarathe/"
 ],
 [
  "Kaviarasan Thangarasu",
  "Director of SAP Data and Analytics",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/kaviarasan.webp",
  "https://www.linkedin.com/in/kaviarasan-thangarasu-5913a354"
 ],
 [
  "M.S.Mohanraj",
  "Director of Sales",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/Mohanraj.webp",
  "https://www.linkedin.com/in/msmohanraj/"
 ],
 [
  "Venkata Rama Vikas Chinta",
  "Cloud Advisor",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/Vikas-Chinta.webp",
  "https://www.linkedin.com/in/vikaschinta/"
 ],
 [
  "Robert Jones",
  "Delivery Director, Customer Success",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/Robert-Jones.webp",
  "https://www.linkedin.com/in/robertjones-mba-pmp/"
 ],
 [
  "Suchindra Guru Pradeep Prabhakaran",
  "SAP Finance Advisory",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/Pradeep-Prabhakaran.webp",
  "https://www.linkedin.com/in/pradeep-prabhakaran-1abb64151/"
 ],
 [
  "Sandy Udupa",
  "Director of Finance",
  "https://sierradigitalinc.com/wp-content/uploads/2025/07/Sandy-Udupa.webp",
  "https://www.linkedin.com/in/sandy-udupa-379153115/"
 ]
];
