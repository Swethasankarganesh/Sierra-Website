// Real content from sierradigitalinc.com/about-us/
export const aboutQuote = { text: "At Sierra, our goal is to simplify, extend, and enhance SAP technology as a means of optimizing its value.", by: "Senthil Kumar, Chairman & CEO" };
export const aboutInnovation = {
  h: "Innovation. It's What We're About.",
  p: ["Since our founding in 2002, the Sierra companies have always pointed in the direction of innovation. And the good it can do.",
    "We remember well the birth of smartphone technology 20 years back. Now, the same evolutionary changes are sweeping the enterprise world. From on-prem to cloud; from custom code to no code; from platforms to use case-specific apps.",
    "The benefits to be reaped by the intelligent enterprise are many. Cloud-based apps now offer clustered task groups the power of SAP, but with simple interfaces, extended analytics capability, quick implementation, minimum cost & risk, and more.",
    "Get to know us, SAP’s App Innovation Station. We’ll help you discover all that innovation can deliver to your doorstep."],
};
export const aboutAltitude = {
  h: "Where Altitude is An Attitude.",
  p: ["Decades back, the mountains surrounding a small Indian town were the source of inspiration for a young boy named Senthil Kumar.",
    "He often wondered how, someday, many might enjoy a view from the top of these peaks, rather than a select few.",
    "Senthil applied his boyhood inspiration to found the Sierra companies, a superstore where the masses can reap the rewards of the most advanced technology.",
    "We aspire higher. And value the opportunity to help you do the same."],
};
export const aboutPillars = [
  { h: "Our Purpose", p: "At Sierra Digital, our purpose is to deliver peak performance to customers we serve. We succeed when we lead people to realize how they benefit from accepting and embracing imminent, transformational change driven by technology." },
  { h: "Our Mission", p: "Sierra Digital aspires to be a global leader that helps customers transform the traditional business model into a state-of-the-art digital enterprise for ultimate competitive advantage." },
  { h: "Our Vision", p: "To become a beloved technology company, accelerating the customer’s transition to the digital economy with a focus on integrity and sustainability." },
];
export const aboutTimeline: [string, string, string][] = [
  ["2002", "Founded", "Sierra Digital was established with a vision to simplify and enhance SAP technology."],
  ["2004", "Expansion of Services", "The company began expanding its service offerings, focusing on cloud-based applications and enterprise solutions that leverage SAP technologies."],
  ["2010", "Establishment of Delivery Centers", "The company expanded its operational footprint by establishing delivery centers in the U.S. and India, enhancing its capacity to serve a global client base."],
  ["2020", "Launch of New Solutions", "Sierra Digital introduced several new application solutions built on SAP BTP that work to enhance and simplify business processes while extending the value of our customer’s SAP investments."],
  ["2021", "Stonebridge Acquisition", "We acquired Stonebridge, a boutique consultancy with robust IP and deep industry expertise in Oil and Gas, strengthening our position as a top-tier partner to Oil, Gas, and Energy."],
  ["2023", "Migration Assessments", "Sierra Digital began releasing a suite of Readiness Assessments, a line of products called InFocus, that simplifies and accelerates the modernization of legacy SAP systems."],
  ["2024", "Over 20 GenAI Use Case", "Sierra developed over 20 Gen-AI use cases across various industries driving tangible benefits for clients like Energy and Natural Resources, Consumer, Public Services, Services and many more"],
  ["2025", "New Acquisition", "Sierra acquired another SAP consultancy specializing in Manufacturing, Utilities and Pharma, with this acquisition Sierra's global reach expands with over 800+ consultants across North America, Europe, Australia, and Asia, Sierra now delivers enhanced capabilities and innovative SAP solutions to clients worldwide."],
  ["2025", "Sierra AppHaus Houston", "A space designed to foster innovation and digital transformation . At Sierra AppHaus Houston, the SAP community will drive innovation to new heights, equipped with world-class tools and expert guidance from Sierra Digital."],
];
