import { solutions } from "./solutions";
import { services } from "./services";
import { products } from "./products";
import { industries } from "./industries";
import { articles } from "./insights";
import { company } from "./pages";
import { SOURCE } from "./site";
const it = (t: string, d: string, href: string) => ({ t, d, href });
export const menus = [
 { label: "Solutions", href: "/solutions", groups: [
  { title: "SAP & Data", items: solutions.slice(0, 4).map(s => it(s.title, s.short, `/solutions/${s.slug}`)) },
  { title: "AI, Cloud & Integration", items: solutions.slice(4).map(s => it(s.title, s.short, `/solutions/${s.slug}`)) }] },
 { label: "Services", href: "/services", groups: [
  { title: "Modernisation lifecycle", items: services.map(s => it(s.title, s.short, `/services/${s.slug}`)) },
  { title: "Business processes", items: [it("Transformation approach", "From understanding to optimising.", "/business-transformation"), it("Order to Cash", "Customer order to payment.", "/business-transformation/order-to-cash"), it("All business processes", "Six processes Sierra can transform.", "/business-transformation/processes")] }] },
 { label: "Products", href: "/products", groups: [{ title: "Products", items: [...products.map(p => it(p.title, p.tag, `/products/${p.slug}`)), it("All products", "Purpose-built solutions.", "/products")] }] },
 { label: "Industries", href: "/industries", groups: [{ title: "Industries", items: industries.slice(0, 5).map(i => it(i.title, "How Sierra transforms this sector.", `/industries/${i.slug}`)).concat([it("All industries", "12 industries served.", "/industries")]) }] },
 { label: "Resources", href: "/insights", groups: [{ title: "Resources", items: [it("Customer stories", "Sierra clients in their own words.", "/case-studies"), ...articles.slice(0, 3).map(a => it(a.title, a.kind, `/insights/${a.slug}`)), it("All resources", "Articles, events and webinars.", "/insights")] }] },
 { label: "Company", href: "/company", groups: [{ title: "Company", items: [...Object.entries(company).map(([k, v]) => it(v.title, v.intro, `/company/${k}`)), it("Contact", "Start a conversation.", "/contact")] }] },
];
